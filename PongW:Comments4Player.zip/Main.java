// Main Class 
public class Main {
	// Main method - creates a new game and runs it. 
	public static void main(String[] args) {
		new Game();
	}
}
