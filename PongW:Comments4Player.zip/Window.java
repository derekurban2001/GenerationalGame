// method to create the window using JFrame
import javax.swing.JFrame;

public class Window {

// Constructor - Creates the window for the game
// Parameters: 
// title: takes the String title for the name of the game.
// game: Parameter of the class type "Game" to create the game
	public Window(String title, Game game) {
		JFrame frame = new JFrame(title);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.add(game); 
		frame.pack();
		frame.setLocationRelativeTo(null); 
		frame.setVisible(true);
	}

}
