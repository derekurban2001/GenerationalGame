import java.util.Scanner;

public class Game {
	//Size for the screen
	public final static int WIDTH = 1000;
	public final static int HEIGHT = 1000;
	
	Scanner input = new Scanner(System.in);
	
	int paddleX =10, paddleY=Game.HEIGHT/2, paddleLength=75, paddleWidth=5;
	//Creating the object
	private Ball ball = new Ball();
	private Paddle paddle = new Paddle(paddleX,paddleY,paddleLength,paddleWidth);
	
	//Method to run the game
	public Game() {
		int x = 0; //int for the while loop
		double k = Game.WIDTH / 2 - ball.SIZE / 2; //x coordinate for setting the ball to the center of the screen initially
		double o = Game.HEIGHT / 2 - ball.SIZE / 2; //y coordinate for setting the ball to the center of the screen initially
		
		int ychangeup = -10;
		int ychangedown = 10;
		System.out.println("Enter 'Ball Demo' to show demo of ball movement - Make sure to scroll up after!");
		System.out.println("Enter 'Paddle Demo' to show demo of paddle movement");
		
		//while loop for 250 movements for the text-based version
		String s = input.nextLine();
		if (s.equals("Ball Demo")) {
			
		while ( x < 250) {
			
			try {
				Thread.sleep(500);
			}
			catch(Exception ex) {};
			//print statement for current location of the ball
			System.out.println("The current ball position is:"+ ball.getX() + "(x-coordinate), " + ball.getY()+"(y-coordiate)");
			
			//moving the ball in the direction of the x-velocity
			k += ball.getxVelocity()* ball.getSpeed();
			ball.setX(k);
			//moving the ball in the direction of the y velocity
			o += ball.getyVelocity()*ball.getSpeed();
			ball.setY(o);
			//checking the ball for wall contact, which then changes the direction the ball is traveling
			ball.checkWallContact(ball);
			x+=1;
			
			}
		
		}
		else if (s.equals("Paddle Demo")){
			System.out.println("The current paddle position is:(" + paddle.getX()+","+ paddle.getY()+")");
			System.out.println("Enter which way you want to move the paddle('up' or 'down') & 'exit' to Exit");
			String m = input.next();
			while(!m.equals("exit")) {
			if(m.equals("up")) {
				paddle.change(ychangeup);
				System.out.println("The new paddle position is: (" + paddle.getX()+ "," + paddle.getY()+")");
			}
			else if(m.equals("down")) {
				paddle.change(ychangedown);
				System.out.println("The new paddle position is: (" + paddle.getX()+ "," + paddle.getY()+")");
			}
			else if(m.equals("exit")) {
				System.exit(0);
			}
			else {
				System.out.println("Invalid Command! Shutting down program.");
				System.exit(0);
				}
			System.out.println("Enter which way you want to move the paddle('up' or 'down') & 'exit' to Exit");
			m = input.next();
			}
		}
		
		else {
			System.out.println("Invalid Command, Shutting down program!");
			System.exit(0);
				
		}
	}
	//main method - Will be in its own class for the rest of the project
	public static void main(String[] args) {
		new Game();
		}
}
