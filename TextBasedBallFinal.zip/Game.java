
public class Game {
	//Size for the screen
	public final static int WIDTH = 1000;
	public final static int HEIGHT = 1000;
	
	//Creating the object
	private Ball ball = new Ball();
	
	//Method to run the game
	public Game() {
		int x = 0; //int for the while loop
		double k = Game.WIDTH / 2 - ball.SIZE / 2; //x coordinate for setting the ball to the center of the screen initially
		double o = Game.HEIGHT / 2 - ball.SIZE / 2; //y coordinate for setting the ball to the center of the screen initially
		
		//while loop for 500 movements for the text-based version
		while ( x < 500) {
		
			//print statement for current location of the ball
			System.out.println("The current ball position is:"+ ball.getX() + "(x-coordinate), " + ball.getY()+"(y-coordiate)");
			
			//moving the ball in the direction of the x-velocity
			k += ball.getxVelocity()* ball.getSpeed();
			ball.setX(k);
			//moving the ball in the direction of the y velocity
			o += ball.getyVelocity()*ball.getSpeed();
			ball.setY(o);
			//checking the ball for wall contact, which then changes the direction the ball is traveling
			ball.checkWallContact(ball);
			x+=1;
			
		}
	}
	//main method - Will be in its own class for the rest of the project
	public static void main(String[] args) {
		new Game();
		}
}
