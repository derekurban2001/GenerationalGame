//Some of the code in this game was created using the following tutorial: https://www.youtube.com/watch?v=MPJ8XRpZZCk

//Class for the Ball
public class Ball {

	// Size of the ball
	public static final int SIZE = 20;

	private double x, y; //doubles for the top left pixel location of the ball
	private double xVelocity, yVelocity; // doubles for the direction of the ball
	private int speed = 20; //int for the rate of movement for the ball
	
	public Ball() {
		reset();// resetting the ball initially
	}

	//reset function to place the ball in the middle of the screen
	// x and y velocities are randomly generated initially 
	private void reset() {
			x = Game.WIDTH / 2 - SIZE / 2;
			y = Game.HEIGHT / 2 - SIZE / 2;

			xVelocity = (Math.random() * 4.0 - 1);
			yVelocity = (Math.random() * 4.0 - 1);
		}

	//Method to determine if the ball makes contact with any wall. If it does, the ball reflects off the wall.
	//Takes the parameter of any object of this class.
	public void checkWallContact(Ball ball) {
			
			if (y + SIZE >= Game.HEIGHT || y <= 0) {
				System.out.println("Bounced off Floor or Ceiling!");
					setY(yVelocity *= -1);
					}
			if (x + SIZE >= Game.WIDTH || x <= 0) {
				System.out.println("Bounced off Left or Right Wall!");
					setY(xVelocity *= -1);
					}
			
	}
	//Getter for the x value of top left corner of the ball
	public double getX() {
		return x;
	}
	//Getter for the y value of top left corner of the ball
	public double getY() {
		return y;
	}
	//Getter for the xVelocity of the ball
	public double getxVelocity() {
		return xVelocity;
	}
	//Getter for the yVelocity of the ball
	public double getyVelocity() {
		return yVelocity;
	}
	//Getter for the speed of the ball
	public int getSpeed() {
		return speed;
	}
	//Setter for the x-value of the top left corner of the ball
	public void setX(double k) {
		x = k;
	}
	//Setter for the y-value of the top-left corner of the ball
	public void setY(double o) {
		y = o;
	}
}
	