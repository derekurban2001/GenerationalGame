package superclasses;
import static pixelpartymenu.CoreFrame.contentPane;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.KeyStroke;

/**
 * The Class PhidgetHandlerSuper.
 * 
 * This is meant to be the super (parent) class for all PhidgetHanders and
 * is meant to be a replacement for a physical game controller, and instead
 * will allow for keyboard input from the user. This class handles the bulk
 * for the key-bindings and input listening from the user.
 * 
 * @author Derek Urban
 */
public abstract class PhidgetHandlerSuper{
	
	//Declare important constants and variables
	private JComponent mainFrame = contentPane;
	private static final String PLAYER_ONE = "playerOne";
	private static final String PLAYER_TWO = "playerTwo";
	private static final String PLAYER_THREE = "playerThree";
	private static final String PLAYER_FOUR = "playerFour";
	
	private boolean p1Act = true;
	private boolean p2Act = true;
	private boolean p3Act = true;
	private boolean p4Act = true;
	
	private static InputMap iMap;
	private static ActionMap aMap;
	
	/**
	 * Instantiates a new phidget handler super.
	 * 
	 * Constructor that takes in a frame to overwrite the default frame (one on the main menu)
	 *
	 * @param frame the frame
	 */
	protected PhidgetHandlerSuper(JComponent frame){
		mainFrame = frame;
		//Adds keybinds
		addKeyBind(KeyEvent.VK_Q, "playerOne", playerOnePerformAction, playerOneRelease);
		addKeyBind(KeyEvent.VK_R, "playerTwo", playerTwoPerformAction, playerTwoRelease);
		addKeyBind(KeyEvent.VK_U, "playerThree", playerThreePerformAction, playerThreeRelease);
		addKeyBind(KeyEvent.VK_P, "playerFour", playerFourPerformAction, playerFourRelease);
	}
	
	/**
	 * Instantiates a new phidget handler super.
	 * 
	 * Constructor that doesn't overwrite the default frame
	 */
	protected PhidgetHandlerSuper(){
		//Adds keybinds
		addKeyBind(KeyEvent.VK_Q, "playerOne", playerOnePerformAction, playerOneRelease);
		addKeyBind(KeyEvent.VK_R, "playerTwo", playerTwoPerformAction, playerTwoRelease);
		addKeyBind(KeyEvent.VK_U, "playerThree", playerThreePerformAction, playerThreeRelease);
		addKeyBind(KeyEvent.VK_P, "playerFour", playerFourPerformAction, playerFourRelease);
	}
	
	/**
	 * Player one action.
	 */
	public abstract void playerOneAction();
	
	/**
	 * Player two action.
	 */
	public abstract void playerTwoAction();
	
	/**
	 * Player three action.
	 */
	public abstract void playerThreeAction();
	
	/**
	 * Player four action.
	 */
	public abstract void playerFourAction();
	
	/**
	 * Adds the key bind.
	 *
	 * @param key the key
	 * @param playerConstant the player constant
	 * @param act the action
	 * @param actRelease the action on release
	 */
	private void addKeyBind(int key, String playerConstant, Action act, Action actRelease) {
		//adds to the input map and action map with the appropriate key and action
	    iMap = mainFrame.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
	    aMap = mainFrame.getActionMap();
	    iMap.put(KeyStroke.getKeyStroke(key, 0, false), playerConstant);
	    iMap.put(KeyStroke.getKeyStroke(key, 0, true), playerConstant+"Release");
	    aMap.put(playerConstant, act);
	    aMap.put(playerConstant+"Release", actRelease);
	}
	
	/**DECLARES ALL THE ACTIONS FOR EACH PLAYER, INSTANTIATED BY THE CHILD CLASSES. */
	
	/** The player one perform action. */
	Action playerOnePerformAction = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {
			if(p1Act)
				playerOneAction();
			p1Act = false;
		}
	};
	
	/** The player two perform action. */
	Action playerTwoPerformAction = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {
			if(p2Act)
				playerTwoAction();
			p2Act = false;
		}
	};
	
	/** The player three perform action. */
	Action playerThreePerformAction = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {
			if(p3Act)
				playerThreeAction();
			p3Act = false;
		}
	};
	
	/** The player four perform action. */
	Action playerFourPerformAction = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {
			if(p4Act)
				playerFourAction();
			p4Act = false;
		}
	};
	
	/** The player one release action. */
	Action playerOneRelease = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {p1Act = true;}
	};
	
	/** The player two release action. */
	Action playerTwoRelease = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {p2Act = true;}
	};
	
	/** The player three release action. */
	Action playerThreeRelease = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {p3Act = true;}
	};
	
	/** The player four release action. */
	Action playerFourRelease = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {p4Act = true;}
	};
}
