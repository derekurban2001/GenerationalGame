package superclasses;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;

/**
 * The Class ImageChanger.
 * 
 * This class allows images to change their colors from another color.
 * This class is meant to be used on the player objects for the three games
 * and allow them to be changed to the colors the players pick in the main menu.
 * 
 * @author Derek Urban
 */
public class ImageChanger {
	
	/**
	 * Change image color.
	 *
	 * Takes in an image, and changes all the colored pixels from
	 * one color to another, then returns the changed/colorized image.
	 *
	 * @param image the image
	 * @param from the from color
	 * @param to the to color
	 * @return the buffered image
	 */
	public static BufferedImage changeImageColor(BufferedImage image, Color from, Color to) {
		
		//initializes both colors and gets the dimensions of the image
		int[] fromColor = {from.getRed(), from.getGreen(), from.getBlue()};
		int[] toColor = {to.getRed(), to.getGreen(), to.getBlue()};
	    int width = image.getWidth();
	    int height = image.getHeight();
	    //rasterizes the image
	    WritableRaster raster = image.getRaster();
	    
	    //goes in pixel by pixel and changes each colored pixel to the a new colored pixel
	    for (int xx = 0; xx < width; xx++) {
	      for (int yy = 0; yy < height; yy++) {
	        int[] pixels = raster.getPixel(xx, yy, (int[]) null);
	        if(pixels[0] == fromColor[0] && pixels[1] == fromColor[1] && pixels[2] == fromColor[2]) {
	            pixels[0] = toColor[0];
	            pixels[1] = toColor[1];
	            pixels[2] = toColor[2];
	            raster.setPixel(xx, yy, pixels);
	        }
	      }
	    }
	    
	    //returns the image
	    return image;
	  }
}
