package pacman;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JLabel;

/**
 * The Class GameClock.
 * 
 * The GameClock class handls the timer for the game, as
 * well as the scaling difficulty, and also prompts for
 * when the game is over, and should begin cleanup
 * 
 * @author Derek Urban
 */
public class GameClock {
	
	private static Thread DifficultyScaler = new Thread(new difficultyScaler(), "Hitbox Checker");
	private static int difficulty = 0, endCount = 3;
	private static JLabel jClock;
	private static Player[] playerList;
	private static Player player1, player2;
	private static boolean gameOver = false;
	
	/**
	 * Instantiates a new game clock.
	 *
	 * @param iClock the incoming clock
	 * @param iPlayerList the incoming player list
	 */
	protected GameClock(JLabel iClock, Player[] iPlayerList){
		playerList = iPlayerList;
		player1 = playerList[0];
		player2 = playerList[1];
		jClock = iClock;
		DifficultyScaler.start();
	}
	
	/**
	 * Instantiates a new game clock.
	 */
	protected GameClock(){}
	
	/**
	 * The Class difficultyScaler.
	 */
	private static class difficultyScaler implements Runnable{
		
		/**
		 * Run.
		 */
		@Override
		public void run() {
			int count = 0;
			while(true) {
				//Pause for one second
				try {
					Thread.sleep(1000);
				}
				catch(Exception ex) {ex.printStackTrace();}
				
				//If the count is under 90 (didn't run out of time) and atleast one player is alive
				if(count<90 && (playerList[0].isAlive() || playerList[1].isAlive())) {
					//then update the clock and slowly increase difficulty
					jClock.setText("Timer: "+count);
					if(count%5 == 0) {
						if(difficulty+1 < 15) {
							difficulty += 1;
						}
					}
					count+=1;
					//update the scores for all alive players
					if(player1.isAlive())
						player1.addScore(difficulty*10);
					if(player2.isAlive())
						player2.addScore(difficulty*10);
				}
				//If the game has ended
				else if (!gameOver){
					//hide the clock and exponentially decrease difficulty
					//i.e. slow things down fast!
					jClock.setText("");
					difficulty -= endCount;
					if(difficulty < -200) {
						//when things have objects have practically stopped, end the game
						gameOver = true;
					}
					endCount *= 2;
					
					//update and write the players scores to a text file
					try {
						FileWriter writer = new FileWriter("src/Pacman/scores.txt");
						writer.write("PACMAN SCORES:"
								   + "\nPlayer1:"+player1.getScore()
								   + "\nPlayer2:"+player2.getScore());
						writer.close();
					}
					catch(IOException ex) {ex.getStackTrace();};
				}
			}
		}
	}
	
	/**
	 * Gets the difficulty.
	 *
	 * @return the difficulty
	 */
	protected static int getDifficulty() {
		return difficulty;
	}
	
	/**
	 * Checks if game is over.
	 *
	 * @return true, if game is over
	 */
	protected static boolean isGameOver() {
		return gameOver;
	}
}

