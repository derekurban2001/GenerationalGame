package pacman;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.swing.JLabel;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import superclasses.ImageChanger;

/**
 * The Class AnimationUpdater.
 * 
 * This Class handles all the animations  for game objects
 * and updates them on a separate thread.
 * 
 * @author Derek Urban
 */
public class AnimationUpdater extends GameClock{
	
	private Thread Updater = new Thread(new updater(), "Animation Updater");
	private final Color DEFAULTCOLOR1 = new Color(100,100,100), DEFAULTCOLOR2 = new Color(200,200,200);
	private Player player1;
	private Player player2;
	private File explosionFolder = new File("images/Pacman/Explosion");
	private File pacmanDeathFolder = new File("images/Pacman/PacmanDeath");
	private File pacmanEatingFolder = new File("images/Pacman/PacmanEating");
	private boolean gameOverCheck = true;
	private JLabel jGameOverDisplay;
	private AI[] ghostList;
	
	/**
	 * Instantiates a new animation updater.
	 *
	 * @param iPlayerList the incoming player list
	 * @param iGhostList the incoming ghost list
	 * @param JGameOverDisplay the "game over" display
	 */
	protected AnimationUpdater(Player[] iPlayerList, AI[] iGhostList, JLabel JGameOverDisplay){
		jGameOverDisplay = JGameOverDisplay;
		ghostList = iGhostList;
		player1 = iPlayerList[0];
		player2 = iPlayerList[1];
		Updater.start();
	}
	
	/**
	 * The Class updater.
	 */
	public class updater implements Runnable{
		
		/**
		 * Run.
		 */
		@Override
		public void run() {
			while(true) {
				//if player one is dead, and the user cannot see the player
				if(!player1.isAlive() && player1.playerLabel.isVisible() == true) {
					PlayerDeathAnimation(player1);
				}
				
				//if player two is dead, and the user cannot see the player
				if(!player2.isAlive() && player2.playerLabel.isVisible() == true) {
					PlayerDeathAnimation(player2);
				}
				
				//Cycle through all frames for pacman eating animation
				for(File file: pacmanEatingFolder.listFiles()) {
					//if the player is alive, then update its image
					if(player1.isAlive()) {
						//Color the players animation to that of ther players color from main menu
						BufferedImage img = getImage(file, player1.getPDir(), player1.getSDir());
						img = ImageChanger.changeImageColor(img, DEFAULTCOLOR1, player1.getPlayer1Color());
						img = ImageChanger.changeImageColor(img, DEFAULTCOLOR2, player1.getPlayer3Color());
						player1.playerLabel.setIcon(new ImageIcon(img));
					}
					//if the player is alive, then update its image
					if(player2.isAlive()) {
						//Color the players animation to that of ther players color from main menu
						BufferedImage img = getImage(file, player2.getPDir(), player2.getSDir());
						img = ImageChanger.changeImageColor(img, DEFAULTCOLOR1, player1.getPlayer2Color());
						img = ImageChanger.changeImageColor(img, DEFAULTCOLOR2, player1.getPlayer4Color());
						player2.playerLabel.setIcon(new ImageIcon(img));
					}
					try {
						Thread.sleep(50);
					}
					catch(Exception ex) {ex.printStackTrace();}
					//if all the players are dead and invisible to the user, then stop the loop
					if((!player2.isAlive() && !player2.playerLabel.isVisible()) &&
					   (!player1.isAlive() && !player1.playerLabel.isVisible())) {
						break;
					}
				}
				//if the game has ended and the gameOverCheck is true
				if(isGameOver() && gameOverCheck) {
					//play the death animations for the ghosts, and the GAME OVER label
					GhostsDeathAnimations();
					jGameOverDisplay.setVisible(true);
				}
			}
		}
	}
	
	/**
	 * Ghosts death animations.
	 */
	private void GhostsDeathAnimations() {
		//Cycle through each ghost and each animation frame for the explosions
		for(AI ghost : ghostList) {
			for(File file : explosionFolder.listFiles()) {
				//play the explosion animation for a ghost
				ImageIcon image = null;
				try {
					Thread.sleep(100);
					image = new ImageIcon(ImageIO.read(file));
				}
				catch(Exception ex) {}
				ghost.ghostLabel.setIcon(image);
			}
		}
		//set gameOverCheck to false, to stop the dying animation
		gameOverCheck = false;
	}
	
	/**
	 * Player death animation.
	 *
	 * @param player the player
	 */
	private void PlayerDeathAnimation(Player player) {
		//Cycle through each frame for the players death animation
		for(File file: pacmanDeathFolder.listFiles()) {
			try {
				Thread.sleep(50);
			}
			catch(Exception ex) {ex.printStackTrace();}
			BufferedImage img = getImage(file, player.getPDir(), player.getSDir());
			//Color the players death animation based of the color from the main menu
			if(player.name.equals("Player1")) {
				img = ImageChanger.changeImageColor(img, DEFAULTCOLOR1, player.getPlayer1Color());
				img = ImageChanger.changeImageColor(img, DEFAULTCOLOR2, player.getPlayer3Color());
			}
			else if(player.name.equals("Player2")) {
				img = ImageChanger.changeImageColor(img, DEFAULTCOLOR1, player.getPlayer2Color());
				img = ImageChanger.changeImageColor(img, DEFAULTCOLOR2, player.getPlayer4Color());
			}
			player.playerLabel.setIcon(new ImageIcon(img));
		}
		//Hide the player as it is now dead
		player.playerLabel.setVisible(false);
	}
	
	/**
	 * Gets the image.
	 *
	 * @param file the file
	 * @param pDir the primary direction
	 * @param sDir the secondary direction
	 * @return the image
	 */
	private BufferedImage getImage(File file, String pDir, String sDir){
		BufferedImage bImage = null;
		double num = 0;
		try {
			bImage = ImageIO.read(file);
		}
		catch(Exception ex) {ex.printStackTrace();}
		//Find direction of where the player is facing, and assign num to the
		//corresponding amount of degrees to rotate
		switch(sDir) {
		case("up"):
			num = 1.5;
			break;
		case("down"):
			num = 0.5;
			break;
		case("right"):
			num = 0;
			break;
		case("left"):
			num = 1;
			break;
		case("none"):
			switch(pDir) {
			case("up"):
				num = 1.5;
				break;
			case("down"):
				num = 0.5;
				break;
			case("right"):
				num = 0;
				break;
			case("left"):
				num = 1;
				break;
			}
			break;
		}
		//Rotate the image by the appropriate amount
		bImage = rotateImage(bImage, num);
		return bImage;
	}
	
	/**
	 * Rotate image.
	 *
	 * @param img the incoming img
	 * @param num the num
	 * @return the buffered image
	 */
	private static BufferedImage rotateImage(BufferedImage img, double num) {
	    int width = 36;
	    int height = 36;
	    
	    BufferedImage dest = new BufferedImage(height, width, img.getType());

	    Graphics2D graphics2D = dest.createGraphics();
	    graphics2D.rotate(Math.PI*num, height / 2, width / 2);
	    graphics2D.drawRenderedImage(img, null);
	    graphics2D.dispose();

	    return dest;
	}
}
