package pacman;
import java.awt.EventQueue;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * The Class PacmanMainClass.
 * 
 * The main entry point for the game Pacman, and will extend
 * a GameSuper superclass when functionality is implemented to
 * allow an easy and organized prompting and closing of games
 * 
 * *main is temporarily housed in this class for pacman*
 * 
 * @author Derek Urban
 */
public class PacmanMainClass {
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI gui = new GUI();
					JPanel panel = gui.getMainPanel();
					JFrame frame = new JFrame();
					frame.setVisible(true);
					frame.setResizable(false);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.setBounds(0, 0, 545, 598+28);
					panel.setVisible(true);
					frame.setContentPane(panel);
					frame.setLocationRelativeTo(null);
					//Wipes the scores and prepares for new game
					FileWriter writer = new FileWriter("src/Pacman/scores.txt");
					writer.write("PACMAN SCORES:"
							  + "\nPlayer1:0"
							  + "\nPlayer2:0");
				    writer.close();	
				} 
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}

