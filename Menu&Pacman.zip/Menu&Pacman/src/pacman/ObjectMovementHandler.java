package pacman;
import javax.swing.JLabel;

/**
 * The Class ObjectMovementHandler.
 * 
 * This class handles all the movement for the objects in the game
 * environment, and runs a separate thread to handle this.
 * 
 * @author Derek Urban
 */
public class ObjectMovementHandler extends GameClock{
	
	private Thread Handler = new Thread(new handler(), "Hitbox Checker");
	private Player playerList[];
	private AI ghostList[];
	private JLabel player1ScoreDisplay, player2ScoreDisplay;
	
	/**
	 * Instantiates a new object movement handler.
	 *
	 * @param iPlayerList the incoming player list
	 * @param iGhostList the incoming ghost list
	 * @param jClock the incoming jClock (JLabel)
	 * @param iPlayer1ScoreDisplay the incoming player 1 score display
	 * @param iPlayer2ScoreDisplay the incoming player 2 score display
	 */
	protected ObjectMovementHandler(Player[] iPlayerList, AI[] iGhostList, JLabel jClock, JLabel iPlayer1ScoreDisplay, JLabel iPlayer2ScoreDisplay){
		super(jClock, iPlayerList);
		player1ScoreDisplay = iPlayer1ScoreDisplay;
		player2ScoreDisplay = iPlayer2ScoreDisplay;
		playerList = iPlayerList;
		ghostList = iGhostList;
		Handler.start();
	}
	
	/**
	 * The Class handler.
	 */
	private class handler implements Runnable{
		
		/**
		 * Run.
		 */
		@Override
		public void run() {
			while(true) {
				//Sets object update interval smaller as time progresses
				//i.e. objects get faster over time
				try {
					Thread.sleep(15-getDifficulty());
				}
				catch(Exception ex) {ex.printStackTrace();}
				
				//update the scores for each player
				updateScores();
				
				//Move each player
				for(Player player:playerList) {
					player.move();
				}
				
				//Move each ghost
				for(AI ghost:ghostList) {
					ghost.move();
				}
				
				//if any player overlaps with any ghost, kill the player
				for(Player player:playerList) {
					for(AI ghost:ghostList) {
						if(checkOverlap(player, ghost)){
							player.kill();
						}
					}
				}
			}
		}
	}
	
	/**
	 * Check overlap.
	 *
	 * @param player the player
	 * @param ghost the ghost
	 * @return true, if successful
	 */
	private boolean checkOverlap(Player player, AI ghost) {
		int playerX = player.getX()+5, playerY = player.getY()+5;
		int ghostX = ghost.getX()+5, ghostY = ghost.getY()+5;
		int width = 26;
		//if the player is within the ghosts X value, return true to kill
		if((playerX >= ghostX && playerX <= ghostX+width) && (playerY >= ghostY && playerY <= ghostY+width) ) {
			return true;
		}
		//if the player is within the ghosts Y value, return true to kill
		else if((playerX+width >= ghostX && playerX+width <= ghostX+width) && (playerY+width >= ghostY && playerY+width <= ghostY+width) ) {
			return true;
		}
		//otherwise return false
		return false;
	}
	
	/**
	 * Update scores.
	 */
	private void updateScores() {
		String temp1 = "00000"+playerList[0].getScore();
		String temp2 = "00000"+playerList[1].getScore();
		String p1Score = temp1.substring(temp1.length()-5);
		String p2Score = temp2.substring(temp2.length()-5);
		player1ScoreDisplay.setText(p1Score);
		player2ScoreDisplay.setText(p2Score);
	}
}
