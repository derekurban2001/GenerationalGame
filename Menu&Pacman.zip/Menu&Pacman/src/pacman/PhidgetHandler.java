package pacman;
import superclasses.PhidgetHandlerSuper;

/**
 * The Class PhidgetHandler.
 * 
 * Replaces the handling method for the physical game controller
 * and instead extends PhidgetHandlerSuper to implement required
 * objects for a keyboard based input system. Controls the input
 * from the user
 * 
 * @author Derek Urban
 */
public class PhidgetHandler extends PhidgetHandlerSuper{
    
    private Player player1, player2;
    
	/**
	 * Instantiates a new phidget handler.
	 *
	 * @param player1 from the incoming player 1
	 * @param player2 from the incoming player 2
	 */
	protected PhidgetHandler(Player iPlayer1, Player iPlayer2){
		//Calls the constructor of the super, and supplies the frame to
		//which the input window should be focused on
		super(GUI.panel);
		this.player1 = iPlayer1;
		this.player2 = iPlayer2;
    }
	
	/**
	 * Player one action.
	 */
	@Override
	public void playerOneAction() {
		player1.goLeft();
	}

	/**
	 * Player two action.
	 */
	@Override
	public void playerTwoAction() {
		player1.goRight();
	}

	/**
	 * Player three action.
	 */
	@Override
	public void playerThreeAction() {
		player2.goLeft();
	}

	/**
	 * Player four action.
	 */
	@Override
	public void playerFourAction() {
		player2.goRight();
	}
}
