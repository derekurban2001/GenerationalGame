package pacman;
import superclasses.PlayerSuper;
import javax.swing.JLabel;

/**
 * The Class Player.
 * 
 * Player will define the player object that is intended to
 * take in user input, and perform actions in order to evade
 * the AI ghosts and to stay alive as long as possible
 * 
 * @author Derek Urban
 */
public class Player extends PlayerSuper{
	
	//initializes components, some are protected as they aren't meant to
	//be encapsulated
	private String pDir = "none", sDir = "none";
	private int score = 0;
	protected String name;
	private boolean[] horizontalList, verticalList;
	private int x = 252, y = 319, xSpeed = 0, ySpeed = 0;
	private boolean alive = true;
	protected JLabel playerLabel;
	//*** PRIMARY DIRECTION: Where the player is facing ***
	//*** SECONDARY DIRECTION: Where the player wants to face next ***
	
	/**
	 * Instantiates a new player.
	 *
	 * @param iJLabel the incoming JLabel
	 * @param iName the incoming name
	 */
	protected Player(JLabel iJLabel, String iName){
		this.name = iName;
		playerLabel = iJLabel;
	}
	
	/**
	 * Move.
	 */
	protected void move() {
		//updates booleans for vertical and horizontal move availability lists
		updateVerticalList();
    	updateHorizontalList();
 		int i = -1;
 		//Check secondary movement direction
 		if(sDir == "up" || sDir == "down") {
 			//repeat until a valid move is found
 			do {
        		i += 1;
        		if(sDir == "up") {
        			ySpeed = -1;
        			//updates booleans for vertical move availability lists
        			updateVerticalList();
        			//when a valid move is found, set it to primary move direction
        			//update the location once, and clear the secondary direction
        			if(verticalList[i]) {
        				pDir = "up";
        				sDir = "none";
        				y += ySpeed;
        			}
        		}
        		else if(sDir == "down") {
        			ySpeed = 1;
        			//updates booleans for vertical move availability lists
        			updateVerticalList();
        			//when a valid move is found, set it to primary move direction
        			//update the location once, and clear the secondary direction
        			if(verticalList[i]) {
        				pDir = "down";
        				sDir = "none";
        				y += ySpeed;
        			}
        		}
        	}
        	while(verticalList[i] == false && i < verticalList.length-1);
 		}
 		else if(sDir == "left" || sDir == "right") {
 			//repeat until a valid move is found
 			do {
        		i += 1;
        		if(sDir == "left") {
        			xSpeed = -1;
        			//updates booleans for horizontal move availability lists
        			updateHorizontalList();
        			//when a valid move is found, set it to primary move direction
        			//update the location once, and clear the secondary direction
        			if(horizontalList[i]) {
        				pDir = "left";
        				sDir = "none";
        				x += xSpeed;
        			}
        		}
        		else if(sDir == "right") {
        			xSpeed = 1;
        			//updates booleans for horizontal move availability lists
        			updateHorizontalList();
        			//when a valid move is found, set it to primary move direction
        			//update the location once, and clear the secondary direction
        			if(horizontalList[i]) {
        				pDir = "right";
        				sDir = "none";
        				x += xSpeed;
        			}
        		}
        	}
        	while(horizontalList[i] == false && i < horizontalList.length-1);
 		}
 		i = -1;
 		//Check primary movement direction, after checking secondary movement direction
 		if(pDir == "up" || pDir == "down") {
 			//repeat until a valid move is found
 			do {
        		i += 1;
        		if(pDir == "up") {
        			ySpeed = -1;
        			//updates booleans for vertical move availability lists
        			updateVerticalList();
        			//when a valid move is found, set it to primary move direction
        			//update the location once, and clear the secondary direction
        			if(verticalList[i]) {
        				y += ySpeed;
        			}
        		}
        		else if(pDir == "down") {
        			ySpeed = 1;
        			//updates booleans for vertical move availability lists
        			updateVerticalList();
        			//when a valid move is found, set it to primary move direction
        			//update the location once, and clear the secondary direction
        			if(verticalList[i]) {
        				y += ySpeed;
        			}
        		}
        	}
        	while(verticalList[i] == false && i < verticalList.length-1);
 		}
 		else if(pDir == "left" || pDir == "right") {
 			//repeat until a valid move is found
 			do {
        		i += 1;
        		if(pDir == "left") {
        			xSpeed = -1;
        			//updates booleans for horizontal move availability lists
        			updateHorizontalList();
        			//when a valid move is found, set it to primary move direction
        			//update the location once, and clear the secondary direction
        			if(horizontalList[i]) {
        				x += xSpeed;
        			}
        		}
        		else if(pDir == "right") {
        			xSpeed = 1;
        			//updates booleans for horizontal move availability lists
        			updateHorizontalList();
        			//when a valid move is found, set it to primary move direction
        			//update the location once, and clear the secondary direction
        			if(horizontalList[i]) {
        				x += xSpeed;
        			}
        		}
        	}
        	while(horizontalList[i] == false && i < horizontalList.length-1);
 		}
 		//If the player reaches a map loop, then update position accordingly
 		if(x == 0 && y == 261) {
 			x = 502;
    	}
    	else if(x==503 && y == 261) {
    		x = 1;
    	}
 		
 		//update player location based off primary/secondary directions
        playerLabel.setLocation(x, y);
	}
	
	/**
	 * Go left.
	 */
	protected void goLeft() {
		//Make the player face 90 degrees to the left
		//Chooses a direction to face based off current facing direction
		if(sDir == "up") {
			sDir = "left";
		}
		else if(sDir == "down") {
			sDir = "right";
		}
		else if(sDir == "left") {
			sDir = "down";
		}
		else if(sDir == "right") {
			sDir = "up";
		}
		else {
			if(pDir == "up") {
				sDir = "left";
			}
			else if(pDir == "down") {
				sDir = "right";
			}
			else if(pDir == "left") {
				sDir = "down";
			}
			else if(pDir == "right") {
				sDir = "up";
			}
			else {
				pDir = "left";
			}
		}
	}
	
	/**
	 * Go right.
	 */
	protected void goRight() {
		//Make the player face 90 degrees to the right
		//Chooses a direction to face based off current facing direction
		if(sDir == "up") {
			sDir = "right";
		}
		else if(sDir == "down") {
			sDir = "left";
		}
		else if(sDir == "left") {
			sDir = "up";
		}
		else if(sDir == "right") {
			sDir = "down";
		}
		else {
			if(pDir == "up") {
				sDir = "right";
			}
			else if(pDir == "down") {
				sDir = "left";
			}
			else if(pDir == "left") {
				sDir = "up";
			}
			else if(pDir == "right") {
				sDir = "down";
			}
			else {
				pDir = "right";
			}
		}
	}
	
	/**
	 * Update horizontal list.
	 */
	private void updateHorizontalList() {
		//Boolean list of all possible routes the player is able to move horizontally
    	horizontalList = new boolean[]{(x+xSpeed>=10 && x+xSpeed<=223 && y==10),
    								   (x+xSpeed>=281 && x+xSpeed<=493 && y==10),
    								   (x+xSpeed>=10 && x+xSpeed<=493 && y==87),
    								   (x+xSpeed>=10 && x+xSpeed<=106 && y==145),
    								   (x+xSpeed>=396 && x+xSpeed<=493 && y==145),
    								   (x+xSpeed>=165 && x+xSpeed<=223 && y==145),
    								   (x+xSpeed>=281 && x+xSpeed<=339 && y==145),
    								   (x+xSpeed>=165 && x+xSpeed<=339 && y==203),
    								   (x+xSpeed>=0 && x+xSpeed<=165 && y==261),
    								   (x+xSpeed>=339 && x+xSpeed<=503 && y==261),
    								   (x+xSpeed>=165 && x+xSpeed<=339 && y==319),
    								   (x+xSpeed>=10 && x+xSpeed<=223 && y==377),
    								   (x+xSpeed>=281 && x+xSpeed<=493 && y==377),
    								   (x+xSpeed>=10 && x+xSpeed<=47 && y==435),
    								   (x+xSpeed>=453 && x+xSpeed<=493 && y==435),
    								   (x+xSpeed>=106 && x+xSpeed<=396 && y==435),
    								   (x+xSpeed>=10 && x+xSpeed<=106 && y==493),
    								   (x+xSpeed>=396 && x+xSpeed<=493 && y==493),
    								   (x+xSpeed>=165 && x+xSpeed<=223 && y==493),
    								   (x+xSpeed>=281 && x+xSpeed<=339 && y==493),
    								   (x+xSpeed>=10 && x+xSpeed<=493 && y==550)};
    }
	
	/**
	 * Update vertical list.
	 */
	private void updateVerticalList() {
		//Boolean list of all possible routes the player is able to move vertically
    	verticalList = new boolean[]{(y+ySpeed>=10 && y+ySpeed<=145 && x==10),
    								 (y+ySpeed>=377 && y+ySpeed<=435 && x==10),
    								 (y+ySpeed>=493 && y+ySpeed<=550 && x==10),
    								 (y+ySpeed>=435 && y+ySpeed<=493 && x==47),
    								 (y+ySpeed>=10 && y+ySpeed<=493 && x==106),
    								 (y+ySpeed>=87 && y+ySpeed<=145 && x==165),
    								 (y+ySpeed>=203 && y+ySpeed<=377 && x==165),
    								 (y+ySpeed>=435 && y+ySpeed<=493 && x==165),
    								 (y+ySpeed>=10 && y+ySpeed<=87 && x==223),
    								 (y+ySpeed>=145 && y+ySpeed<=203 && x==223),
    								 (y+ySpeed>=377 && y+ySpeed<=435 && x==223),
    								 (y+ySpeed>=493 && y+ySpeed<=550 && x==223),
    								 (y+ySpeed>=10 && y+ySpeed<=87 && x==281),
    								 (y+ySpeed>=145 && y+ySpeed<=203 && x==281),
    								 (y+ySpeed>=377 && y+ySpeed<=435 && x==281),
    								 (y+ySpeed>=493 && y+ySpeed<=550 && x==281),
    								 (y+ySpeed>=87 && y+ySpeed<=145 && x==339),
    								 (y+ySpeed>=203 && y+ySpeed<=377 && x==339),
    								 (y+ySpeed>=435 && y+ySpeed<=493 && x==339),
    								 (y+ySpeed>=10 && y+ySpeed<=493 && x==396),
    								 (y+ySpeed>=435 && y+ySpeed<=493 && x==453),
    								 (y+ySpeed>=10 && y+ySpeed<=145 && x==493),
    								 (y+ySpeed>=377 && y+ySpeed<=435 && x==493),
    								 (y+ySpeed>=493 && y+ySpeed<=550 && x==493)};
    }
	
	/**
	 * To string.
	 *
	 * @return the string
	 */
	public String toString() {
		return name;
	}
	
	/**
	 * Gets the x.
	 *
	 * @return the x
	 */
	protected int getX() {
		return x;
	}
	
	/**
	 * Gets the y.
	 *
	 * @return the y
	 */
	protected int getY() {
		return y;
	}
	
	/**
	 * Kill.
	 */
	protected void kill() {
		alive = false;
	}
	
	/**
	 * Checks if player is alive.
	 *
	 * @return true, if player is alive
	 */
	protected boolean isAlive(){
		return alive;
	}
	
	/**
	 * Gets the secondary direction
	 *
	 * @return the secondary direction
	 */
	protected String getSDir() {
		return sDir;
	}
	
	/**
	 * Gets the primary direction
	 *
	 * @return the primary direction
	 */
	protected String getPDir() {
		return pDir;
	}
	
	/**
	 * Gets the score.
	 *
	 * @return the score
	 */
	protected int getScore() {
		return score;
	}
	
	/**
	 * Adds the score.
	 *
	 * @param num the num
	 */
	protected void addScore(int num) {
		score += num;
	}
	
}
