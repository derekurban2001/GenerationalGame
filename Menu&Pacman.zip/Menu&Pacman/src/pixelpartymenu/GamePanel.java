package pixelpartymenu;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

/**
 * The Class GamePanel.
 * 
 * This class handles the implementation of the separate game
 * components into the main menu GUI. This will start, run and
 * end all three games in the order that has been randomly
 * selected
 * 
 * @author Derek Urban
 */
public class GamePanel {
	
	//Declare variables, some are specifically protected as they are not
	//mean't to be encapsulated.
	protected JPanel panel;
	private ImageIcon BackBIcon, BackBHIcon, BackgroundIcon, XBIcon, XBHIcon;
	private JPanel preGamePanel;
	private Game firstGame, secondGame, thirdGame;
	private Game gameFrogger = new Game("Frogger");
	private Game gamePong = new Game("Pong");
	private Game gamePacman = new Game("Pacman");
	private ArrayList<Game> gameOrderArray;
	
	/**
	 * Instantiates a new game panel.
	 */
	protected GamePanel() {
		gameOrderArray = new ArrayList<Game>();
		//initializes all images used by the panel
		try {
			BackBIcon = new ImageIcon(ImageIO.read(new File("images/Menu/BackButton.png")));
			BackBHIcon = new ImageIcon(ImageIO.read(new File("images/Menu/BackButtonHighlighted.png")));
			XBIcon = new ImageIcon(ImageIO.read(new File("images/Menu/XButton.png")));
			XBHIcon = new ImageIcon(ImageIO.read(new File("images/Menu/XButtonHighlighted.png")));
			BackgroundIcon = new ImageIcon(ImageIO.read(new File("images/Menu/DefaultPanelBackground.png")));
		}
		catch(Exception ex) {ex.printStackTrace();}
		
		//INITIALIZE SWING COMPONENTS
		panel = new JPanel();
		panel.setBackground(Color.GRAY);
		panel.setBorder(null);
		panel.setBounds(40, 26, 670, 670);
		panel.setLocation(335-(panel.getWidth()/2), 335-(panel.getHeight()/2));
		panel.setLayout(null);
		
		JButton jBackButton = new JButton("");
		jBackButton.setIcon(BackBIcon);
		jBackButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				jBackButton.setIcon(BackBHIcon);
			}
			public void mouseExited(MouseEvent arg0) {
				jBackButton.setIcon(BackBIcon);
			}
		});
		jBackButton.setBorder(null);
		jBackButton.setBorderPainted(false);
		jBackButton.setContentAreaFilled(false);
		jBackButton.setFocusable(false);		
		jBackButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				jBackButtonActionPerformed();
			}
		});
		jBackButton.setBounds(45, 39, 89, 51);
		panel.add(jBackButton);
		
		JButton jExitButton = new JButton("");
		jExitButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				jExitButton.setIcon(XBHIcon);
			}
			public void mouseExited(MouseEvent e) {
				jExitButton.setIcon(XBIcon);
			}
		});
		jExitButton.setIcon(XBIcon);
		jExitButton.setFocusable(false);
		jExitButton.setContentAreaFilled(false);
		jExitButton.setBorder(null);
		jExitButton.setBackground(new Color(0,0,0,0));
		jExitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		jExitButton.setBounds(631, 0, 41, 41);
		panel.add(jExitButton);
		
		JLabel lblNewLabel = new JLabel("GAME PANEL");
		lblNewLabel.setBorder(new LineBorder(new Color(0, 0, 0), 3));
		lblNewLabel.setBackground(Color.PINK);
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBounds(190, 222, 278, 88);
		panel.add(lblNewLabel);

		JLabel jBackground = new JLabel("");
		jBackground.setIcon(BackgroundIcon);
		jBackground.setBounds(0, 0, 670, 670);
		panel.add(jBackground);
		
		panel.setVisible(false);
		panel.setOpaque(false);
		
		//Pick a randomized game order
		pickGameOrder();
		
		//start the game Handler to process games.
		new GameHandler(gameOrderArray, panel);
	}
	
	/**
	 * Pick game order.
	 */
	private void pickGameOrder() {
		//Pick two random values, one between 0-2, the other 0-1
		int randomGame1 = (int)(Math.random()*3);
		int randomGame2 = (int)(Math.random()*2);
		
		//Make an array and add all games to it
		ArrayList<Game> tempArray = new ArrayList<Game>();
		tempArray.add(gameFrogger);
		tempArray.add(gamePong);
		tempArray.add(gamePacman);
		
		//Set the first game to the random value between 0-2,
		//and remove from the array
		firstGame = tempArray.get(randomGame1);
		tempArray.remove(randomGame1);
		
		//Set the second game to the random value between 0-1,
		//and remove from the array
		secondGame = tempArray.get(randomGame2);
		tempArray.remove(randomGame2);
		
		//Set the third game to the last object left in the array
		thirdGame = tempArray.get(0);
		
		//Set the game order to the official gameOrderArray
		gameOrderArray.add(firstGame);
		gameOrderArray.add(secondGame);
		gameOrderArray.add(thirdGame);
	}
	
	/**
	 * Perform when back button is pressed
	 */
	private void jBackButtonActionPerformed() {
		preGamePanel.setVisible(true);
		panel.setVisible(false);
	}
	
	/**
	 * Sets the panels.
	 *
	 * @param PreGamePanel the new panels
	 */
	protected void setPanels(JPanel PreGamePanel) {
		preGamePanel = PreGamePanel;
	}

}

