package pixelpartymenu;
import java.util.ArrayList;

import javax.swing.JPanel;

/**
 * The Class GameHandler.
 * 
 * This class will handle all the game transitions, starting, runtimes and endings
 * for all three games. This will be the thread for ensuring the separate games
 * run smoothly and are implemented nicely into the main menu
 * 
 * @author Derek Urban
 * 
 * CURRENTLY UNFINISHED, WILL BE COMPLETED AND FULLY INITIALIZED WHEN ALL
 * GAMES ARE COMPLETE AND FUNCTIONING.
 */
public class GameHandler {
	
	/** The Handler. */
	private Thread Handler = new Thread(new handler());
	
	/** The game order array. */
	private ArrayList<Game> gameOrderArray;
	
	/** The panel. */
	private JPanel panel;
	
	/** The keep playing. */
	private boolean keepPlaying = false;
	
	/**
	 * Instantiates a new game handler.
	 *
	 * @param iGameOrderArray the incoming game order array
	 * @param iPanel the incoming panel
	 */
	protected GameHandler(ArrayList<Game> iGameOrderArray, JPanel iPanel){
		panel = iPanel;
		gameOrderArray = iGameOrderArray;
		Handler.start();
	}
	
	/**
	 * The Class handler.
	 */
	private class handler implements Runnable{
		
		/**
		 * Run.
		 */
		@Override
		public void run() {
			
		}
	}
	
	/**
	 * Prompt games.
	 */
	private void promptGames() {
		for(int i = 0; i < gameOrderArray.size(); i++) {
			Game game = gameOrderArray.get(i);
			
			startGame(game);
			
			while(!game.isOver()) {
				try {
					Thread.sleep(100);
				}
				catch(Exception ex) {ex.printStackTrace();}
			}
			
			endGame(game);
		}
	}
	
	/**
	 * Start game.
	 *
	 * @param iGame the incoming game
	 */
	private void startGame(Game iGame) {
		Game game = iGame;
	}
	
	/**
	 * End game.
	 *
	 * @param iGame the incoming game
	 */
	private void endGame(Game iGame) {
		Game game = iGame;
	}
}
