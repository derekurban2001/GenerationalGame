package pixelpartymenu;
//TEMPORARY CLASS - ONLY MADE FOR CODE RUNNABILITY
//WILL BE MOVED INTO THE SUPERCLASSES FOLDER WHEN FUNCTIONALITY
//AND ALL GAMES HAVE BEEN PACKAGED AND MOVED INTO THIS JAVA PROJECT

/**
 * The Class Game.
 * 
 * TEMPORARY CLASS - ONLY MADE FOR CODE RUNNABILITY
 * WILL BE MOVED INTO THE SUPERCLASSES FOLDER WHEN FUNCTIONALITY
 * AND ALL GAMES HAVE BEEN PACKAGED AND MOVED INTO THIS JAVA PROJECT
 * 
 * @author Derek Urban
 */
public class Game {
	
	/** The name. */
	private String name;
	
	/** The over. */
	boolean over = false;
	
	/**
	 * Instantiates a new game.
	 *
	 * @param s the s
	 */
	Game(String s){
		name = s;
	}
	
	/**
	 * To string.
	 *
	 * @return the string
	 */
	public String toString() {
		return name;
	}
	
	/**
	 * Checks if over.
	 *
	 * @return true, if over
	 */
	public boolean isOver() {
		return over;
	}
}
