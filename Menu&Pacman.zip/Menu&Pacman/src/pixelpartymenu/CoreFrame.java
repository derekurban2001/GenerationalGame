package pixelpartymenu;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

/**
 * The Class CoreFrame.
 * 
 * This class is the Core Frame, it handles the frame that all the
 * panels reside in, it also ensures that all panels are instantiated
 * and setup properly. This is the Core to the scene and GUI of the menu.
 * 
 * @author Derek Urban
 */
public class CoreFrame extends JFrame {

	//Declare variables, some are specifically public as they are not
	//mean't to be encapsulated.
	public static JPanel contentPane;
	private OpeningPanel openingPanel = new OpeningPanel();
	private InfoPanel infoPanel = new InfoPanel();
	private CharacterPanel characterPanel = new CharacterPanel();
	private GamePanel gamePanel = new GamePanel();
	private PreGamePanel preGamePanel = new PreGamePanel();
	
	/**
	 * Instantiates a new core frame.
	 */
	public CoreFrame() {
		setUndecorated(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 670, 670);
		contentPane = new JPanel();
		contentPane.setBorder(null);
		setContentPane(contentPane);
		setBackground(new Color(0,0,0,0));
		setLocationRelativeTo(null);
		contentPane.setLayout(null);
		
		//creates a new PhidgetHandler to handle input for the Menu
		new PhidgetHandler();
		initPanels();
	}
	
	/**
	 * Initializes the panels.
	 */
	private void initPanels() {
		contentPane.add(openingPanel.panel);
		contentPane.add(infoPanel.panel);
		contentPane.add(characterPanel.panel);
		contentPane.add(gamePanel.panel);
		contentPane.add(preGamePanel.panel);
		openingPanel.setPanels(infoPanel.panel);
		infoPanel.setPanels(openingPanel.panel, characterPanel.panel);
		characterPanel.setPanels(infoPanel.panel, preGamePanel.panel);
		preGamePanel.setPanels(characterPanel.panel, gamePanel.panel);
		gamePanel.setPanels(preGamePanel.panel);
	}
}
