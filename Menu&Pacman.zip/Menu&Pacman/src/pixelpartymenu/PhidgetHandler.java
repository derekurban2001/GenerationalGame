package pixelpartymenu;
import javax.swing.JLabel;

import superclasses.PhidgetHandlerSuper;

/**
 * The Class PhidgetHandler.
 * 
 * This class replaces the handler for the physical game controller and
 * instead extends PhidgetHandlerSuper to be able to take a digital 
 * keyboard based input. This handler handles all the user input for the
 * main menu.
 * 
 * @author Derek Urban
 */
public class PhidgetHandler extends PhidgetHandlerSuper{
	
	protected static boolean onCharPanel = false;
	protected static boolean onPreGamePanel = false;
	private int playerOnePos = 0;
	private int playerTwoPos = 0;
	private int playerThreePos = 0;
	private int playerFourPos = 0;
	
	/**
	 * Player one action.
	 */
	//Overrides PhidgetHandlerSuper
	@Override
	//peforms actions for player one
	public void playerOneAction() {
		if(onCharPanel) {
			playerOnePos = nextPlayerColor("PLAYER1", playerOnePos, CharacterPanel.player1Icon);
		}
	}
	
	/**
	 * Player two action.
	 */
	//Overrides PhidgetHandlerSuper
	@Override
	//peforms actions for player two
	public void playerTwoAction() {
		if(onCharPanel) {
			playerTwoPos = nextPlayerColor("PLAYER2", playerTwoPos, CharacterPanel.player2Icon);
		}
	}

	/**
	 * Player three action.
	 */
	//Overrides PhidgetHandlerSuper
	@Override
	//peforms actions for player three
	public void playerThreeAction() {
		if(onCharPanel) {
			playerThreePos = nextPlayerColor("PLAYER3", playerThreePos, CharacterPanel.player3Icon);
		}
	}

	/**
	 * Player four action.
	 */
	//Overrides PhidgetHandlerSuper
	@Override
	//peforms actions for player four
	public void playerFourAction() {
		if(onCharPanel) {
			playerFourPos = nextPlayerColor("PLAYER4", playerFourPos, CharacterPanel.player4Icon);
		}
	}
	
	/**
	 * Next player color.
	 *
	 * @param playerName the player name
	 * @param currentPos the current position
	 * @param playerIcon the player icon
	 * @return the updated current position
	 */
	private int nextPlayerColor(String playerName, int currentPos, JLabel playerIcon) {
		//If the position is over the limited amount, reset it
		if(currentPos>11) {
			currentPos = 0;
		}
		
		//calculate the row and column from a position between 0-11
		int row = currentPos/4;
		int column = currentPos-(row*4);
		
		//Split the current slot section into its occupancy and color
		String playerSlot = CharacterPanel.colorTable[row][column].split(";")[0];
		String colorSlot = CharacterPanel.colorTable[row][column].split(";")[1];
		
		//if the slot is unoccupied
		if(playerSlot.equals("EMPTY")) {
			//Make the slot occupied
			CharacterPanel.colorTable[row][column] = playerName+";"+colorSlot;
			//set the location of the icon to the new occupied space
			playerIcon.setLocation(90+(column*140), 100+(row*140));
		}
		//if the slot is occupied
		else {
			//recursively call for the next position over
			currentPos = nextPlayerColor(playerName, currentPos+1, playerIcon);
			//when that spot is found, reset the original space
			if(playerSlot.equals(playerName)) {
				CharacterPanel.colorTable[row][column] = "EMPTY;"+colorSlot;
			}
		}
		
		//return and update the players position on the table
		return currentPos;
	}

}
