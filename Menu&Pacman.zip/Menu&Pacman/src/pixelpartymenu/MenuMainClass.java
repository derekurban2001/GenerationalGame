package pixelpartymenu;
import java.awt.EventQueue;

/**
 * The Class MenuMainClass.
 * 
 * This class is the main entry point for the menu, it holds the main method
 * and will be used to start the game when all 3 games are fully functioning and
 * fully implemented.
 * 
 * @author Derek Urban
 */
public class MenuMainClass {
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CoreFrame frame = new CoreFrame();
					frame.setVisible(true);
				} 
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
