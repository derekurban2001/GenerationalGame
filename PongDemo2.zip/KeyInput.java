
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class KeyInput extends KeyAdapter {

	private Paddle lp; 
	private Paddle rp; 

	public KeyInput(Paddle p1, Paddle p2) {

		lp = p1;
		rp = p2;
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		if (key == KeyEvent.VK_UP) {
			if(rp.getDirection() == 0) {
				rp.switchDirections(-1);
			}
			else if(rp.getDirection() == 1) {
				rp.switchDirections(-1);
			}
			else if(rp.getDirection() == -1) {
				rp.switchDirections(1);
			}
		}
		if (key == KeyEvent.VK_W) {
			if(lp.getDirection() == 0) {
				lp.switchDirections(-1);
			}
			else if(lp.getDirection() == 1) {
				lp.switchDirections(-1);
			}
			else if(lp.getDirection() == -1) {
				lp.switchDirections(1);
			}
		}

		if (key == KeyEvent.VK_ESCAPE) {
			System.exit(1);
		}
	}
}
