import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import com.phidget22.*;

public class PhidgetHandler{
	boolean port0CS = false, port1CS = false, port2CS = false, port3CS = false, port4CS = false;
	DigitalInput Button1;
    DigitalInput Button2;
    public DigitalOutput PowerStatus;
    Player player1, player2;
    
	PhidgetHandler(Player player1, Player player2) throws PhidgetException {
		this.player1 = player1;
		this.player2 = player2;
		PowerStatus = new DigitalOutput();
        Button1 = new DigitalInput();
        Button2 = new DigitalInput();
        DigitalInput Button3 = new DigitalInput();
        DigitalInput Button4 = new DigitalInput();
        PowerStatus.setIsHubPortDevice(true);
        PowerStatus.setHubPort(0);
        PowerStatus.addAttachListener(onAttachListener);
        PowerStatus.addDetachListener(onDetachListener);
        PowerStatus.addErrorListener(onErrorListener);
        Button1.setIsHubPortDevice(true);
        Button1.setHubPort(1);
        Button1.addAttachListener(onAttachListener);
        Button1.addDetachListener(onDetachListener);
        Button1.addErrorListener(onErrorListener);
        Button1.addStateChangeListener(onStateChangeListener);
        Button2.setIsHubPortDevice(true);
        Button2.setHubPort(2);
        Button2.addAttachListener(onAttachListener);
        Button2.addDetachListener(onDetachListener);
        Button2.addErrorListener(onErrorListener);
        Button2.addStateChangeListener(onStateChangeListener);
        Button3.setIsHubPortDevice(true);
        Button3.setHubPort(3);
        Button3.addAttachListener(onAttachListener);
        Button3.addDetachListener(onDetachListener);
        Button3.addErrorListener(onErrorListener);
        Button3.addStateChangeListener(onStateChangeListener);
        Button4.setIsHubPortDevice(true);
        Button4.setHubPort(4);
        Button4.addAttachListener(onAttachListener);
        Button4.addDetachListener(onDetachListener);
        Button4.addErrorListener(onErrorListener);
        Button4.addStateChangeListener(onStateChangeListener);
        Button1.open();
        Button2.open();
        Button3.open();
        Button4.open();
        PowerStatus.open();	
    }
	
	private DigitalInputStateChangeListener onStateChangeListener = new DigitalInputStateChangeListener() {
		@Override
		public void onStateChange(DigitalInputStateChangeEvent ev) {
			Phidget ch = ev.getSource();
			try {
				if(ch.getHubPort() == 1 && ev.getState())
					player1.goUpLeft();
				if(ch.getHubPort() == 3 && ev.getState())
					player1.goDownRight();
				if(ch.getHubPort() == 4 && ev.getState())
					player2.goUpLeft();
				if(ch.getHubPort() == 2 && ev.getState())
					player2.goDownRight();
			}
			catch(Exception ex) {};
		}
	};
	
	private AttachListener onAttachListener = new AttachListener(){
        @Override
        public void onAttach(AttachEvent ae){             
            Phidget ch = ae.getSource();//GET INFORMATION ABOUT ATTACHED CHANNEL
            try{
                if(ch.getHubPort()==0){
                    System.out.println("Phidget on Port 0 Attached, "+ae.toString());
                    port0CS = true;
                }
                else if(ch.getHubPort()==1) {
                	System.out.println("Phidget on Port 1 Attached, "+ae.toString());
                	port1CS = true;
                }
                else if(ch.getHubPort()==2) {
                	System.out.println("Phidget on Port 2 Attached, "+ae.toString());
                	port2CS = true;
                }
                else if(ch.getHubPort()==3) {
                	System.out.println("Phidget on Port 3 Attached, "+ae.toString());
                	port3CS = true;
                }
                else if(ch.getHubPort()==4) {
                	System.out.println("Phidget on Port 4 Attached, "+ae.toString());
                	port4CS = true;
                }
            }
            catch(PhidgetException ex){
                System.out.println(ex.getDescription());
            }
            checkPhidgetConnection();
        };
    };
    private DetachListener onDetachListener = new DetachListener(){
        @Override
        public void onDetach(DetachEvent ae){
            Phidget ch = ae.getSource();//GET INFORMATION ABOUT ATTACHED CHANNEL
            try{
                if(ch.getHubPort()==0){
                    System.out.println("Phidget on Port 0 Detached, "+ae.toString());
                    port0CS = false;
                }
                else if(ch.getHubPort()==1) {
                	System.out.println("Phidget on Port 1 Detached, "+ae.toString());
                	port0CS = false;
                }
                else if(ch.getHubPort()==2) {
                	System.out.println("Phidget on Port 2 Detached, "+ae.toString());
                	port0CS = false;
                }
                else if(ch.getHubPort()==3) {
                	System.out.println("Phidget on Port 3 Detached, "+ae.toString());
                	port0CS = false;
                }
                else if(ch.getHubPort()==4) {
                	System.out.println("Phidget on Port 4 Detached, "+ae.toString());
                	port0CS = false;
                }
            }
            catch(PhidgetException ex){
                System.out.println(ex.getDescription());
            }
            checkPhidgetConnection();
        };
    };
    private ErrorListener onErrorListener = new ErrorListener(){
        @Override
        public void onError(ErrorEvent ae){
            System.out.println("Error: "+ae.getDescription());
        };
    };
    
    public void checkPhidgetConnection() {
    	try {
    		PowerStatus.setState(port0CS && port1CS && port2CS && port3CS && port4CS);
    	}
    	catch(Exception ex) {};
    }
    public void turnOff() {
    	try {
    		PowerStatus.setState(false);
    	}
    	catch(Exception ex) {};
    }
}
