import java.awt.*;
import java.awt.event.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;

public class GUI extends JPanel{	
	PhidgetHandler phidgetHandler;
	JPanel panel;
    Player pacmanPlayer1;
    Player pacmanPlayer2;
    Player playerList[];
    private JLabel jClock;
	
	public GUI() {
		initComponents();
	}
	
	private void initComponents() {
		AI ghostAI1;
	    AI ghostAI2;
	    AI ghostAI3;
	    AI ghostAI4;
	    JLabel pacmanBoard;
	    JLabel pacmanLabel1;
	    JLabel pacmanLabel2;
	    JLabel ghostLabel1 = null;
	    JLabel ghostLabel2 = null;
	    JLabel ghostLabel3 = null;
	    JLabel ghostLabel4 = null;
		
		panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setBounds(0, 0, 541, 598);
		panel.setLayout(null);
		
		pacmanLabel1 = new JLabel("");
		pacmanLabel1.setBounds(10, 10, 36, 36);
		panel.add(pacmanLabel1);
		
		pacmanLabel2 = new JLabel("");
		pacmanLabel2.setBounds(10, 10, 36, 36);
		panel.add(pacmanLabel2);
		
		pacmanBoard = new JLabel("");
		pacmanBoard.setHorizontalTextPosition(SwingConstants.LEFT);
		pacmanBoard.setHorizontalAlignment(SwingConstants.LEFT);
		try {
			pacmanBoard.setIcon(new ImageIcon("C:\\Users\\Derek Urban\\Documents\\Eclipse Workspace\\Test\\images\\pacmanBoard.png"));
		} catch (Exception ex) {}
		pacmanBoard.setBounds(0, 0, 540, 597);
		
		pacmanPlayer1 = new Player(pacmanLabel1, "Player 1");
		pacmanPlayer2 = new Player(pacmanLabel2, "Player 2");
		playerList = new Player[]{pacmanPlayer1, pacmanPlayer2};
		
		ghostAI1 = addGhost(ghostLabel1, panel, "images/Ghosts/ghostRed.png", "Red Ghost");
		ghostAI2 = addGhost(ghostLabel2, panel, "images/Ghosts/ghostBlue.png", "Blue Ghost");
		ghostAI3 = addGhost(ghostLabel3, panel, "images/Ghosts/ghostPink.png", "Pink Ghost");
		ghostAI4 = addGhost(ghostLabel4, panel, "images/Ghosts/ghostOrange.png", "Orange Ghost");
		
		jClock = new JLabel("Timer: 0");
		jClock.setForeground(new Color(255, 255, 0));
		jClock.setHorizontalAlignment(SwingConstants.CENTER);
		jClock.setFont(new Font("Terminator Two", Font.BOLD, 19));
		jClock.setBorder(null);
		jClock.setBounds(213, 262, 115, 36);
		jClock.setBackground(new Color(0, 0, 0));
		panel.add(jClock);
		
		JLabel jGameOverDisplay = new JLabel("Game Over");
		jGameOverDisplay.setVerticalTextPosition(SwingConstants.TOP);
		jGameOverDisplay.setHorizontalTextPosition(SwingConstants.LEADING);
		jGameOverDisplay.setBounds(0, 248, 540, 66);
		jGameOverDisplay.setForeground(Color.YELLOW);
		jGameOverDisplay.setHorizontalAlignment(SwingConstants.CENTER);
		jGameOverDisplay.setFont(new Font("Terminator Two", Font.BOLD, 72));
		jGameOverDisplay.setBorder(null);
		jGameOverDisplay.setBackground(new Color(0, 0, 0));
		jGameOverDisplay.setVisible(false);
		panel.add(jGameOverDisplay);
		
		JLabel player2DisplayScore1 = new JLabel("Score:");
		player2DisplayScore1.setHorizontalAlignment(SwingConstants.CENTER);
		player2DisplayScore1.setFont(new Font("Terminator Two", Font.BOLD, 20));
		player2DisplayScore1.setForeground(Color.YELLOW);
		player2DisplayScore1.setBounds(448, 311, 92, 24);
		panel.add(player2DisplayScore1);
		
		JLabel player2DisplayScore2 = new JLabel("00000");
		player2DisplayScore2.setHorizontalAlignment(SwingConstants.CENTER);
		player2DisplayScore2.setFont(new Font("Terminator Two", Font.BOLD, 20));
		player2DisplayScore2.setForeground(Color.YELLOW);
		player2DisplayScore2.setBounds(448, 336, 92, 26);
		panel.add(player2DisplayScore2);
		
		JLabel player2DisplayIcon = new JLabel("P2\r\n/4");
		player2DisplayIcon.setHorizontalAlignment(SwingConstants.CENTER);
		player2DisplayIcon.setFont(new Font("Terminator Two", Font.BOLD, 20));
		player2DisplayIcon.setIcon(new ImageIcon("C:\\Users\\Derek Urban\\Documents\\Eclipse Workspace\\Test\\images\\PacmanEating\\PacmanEating08.png"));
		player2DisplayIcon.setForeground(Color.YELLOW);
		player2DisplayIcon.setBounds(448, 197, 92, 48);
		panel.add(player2DisplayIcon);
		
		JLabel player1DisplayScore1 = new JLabel("Score:");
		player1DisplayScore1.setHorizontalAlignment(SwingConstants.CENTER);
		player1DisplayScore1.setForeground(Color.YELLOW);
		player1DisplayScore1.setFont(new Font("Terminator Two", Font.BOLD, 20));
		player1DisplayScore1.setBounds(0, 311, 92, 24);
		panel.add(player1DisplayScore1);
		
		JLabel player1DisplayScore2 = new JLabel("00000");
		player1DisplayScore2.setHorizontalAlignment(SwingConstants.CENTER);
		player1DisplayScore2.setForeground(Color.YELLOW);
		player1DisplayScore2.setFont(new Font("Terminator Two", Font.BOLD, 20));
		player1DisplayScore2.setBounds(0, 335, 92, 26);
		panel.add(player1DisplayScore2);
		
		JLabel player1DisplayIcon = new JLabel("P1/3");
		player1DisplayIcon.setIcon(new ImageIcon("C:\\Users\\Derek Urban\\Documents\\Eclipse Workspace\\Test\\images\\PacmanEating\\PacmanEating08.png"));
		player1DisplayIcon.setHorizontalAlignment(SwingConstants.CENTER);
		player1DisplayIcon.setForeground(Color.YELLOW);
		player1DisplayIcon.setFont(new Font("Terminator Two", Font.BOLD, 20));
		player1DisplayIcon.setBounds(0, 197, 92, 48);
		panel.add(player1DisplayIcon);
		
	    AI ghostList[] = {ghostAI1, ghostAI2, ghostAI3, ghostAI4};
		
	    new ObjectMovementHandler(playerList, ghostList, jClock, player1DisplayScore2, player2DisplayScore2);
	    
		new AnimationUpdater(playerList, ghostList, jGameOverDisplay);
		
		try {
			phidgetHandler = new PhidgetHandler(pacmanPlayer1, pacmanPlayer2);
		}
		catch(Exception ex) {}
		
		panel.add(pacmanBoard);
	}
    
    public AI addGhost(JLabel iLabel, JPanel iPanel, String imageFilePath, String iName) {
    	iLabel = new JLabel("");
    	iLabel.setBounds(10, 10, 36, 36);
		iPanel.add(iLabel);
		
		return new AI(iLabel, imageFilePath, iName, playerList);
    }
    
    public JPanel getMainPanel() {
    	return panel;
    }
}

