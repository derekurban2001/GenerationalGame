import javax.swing.JLabel;

public class ObjectMovementHandler extends GameClock{
	
	private Thread Handler = new Thread(new handler(), "Hitbox Checker");
	private Player playerList[];
	private AI ghostList[];
	private JLabel player1ScoreDisplay, player2ScoreDisplay;
	
	ObjectMovementHandler(Player[] iPlayerList, AI[] iGhostList, JLabel jClock, JLabel iPlayer1ScoreDisplay, JLabel iPlayer2ScoreDisplay){
		super(jClock, iPlayerList);
		player1ScoreDisplay = iPlayer1ScoreDisplay;
		player2ScoreDisplay = iPlayer2ScoreDisplay;
		playerList = iPlayerList;
		ghostList = iGhostList;
		Handler.start();
	}
	
	private class handler implements Runnable{
		@Override
		public void run() {
			while(true) {
				try {
					Thread.sleep(15-getDifficulty());
				}
				catch(Exception ex) {System.out.println(ex);}

				updateScores();
				
				for(Player player:playerList) {
					player.move();
				}
				
				for(AI ghost:ghostList) {
					ghost.move();
				}
				
				for(Player player:playerList) {
					for(AI ghost:ghostList) {
						if(checkOverlap(player, ghost)){
							player.kill();
						}
					}
				}
			}
		}
	}
	
	public boolean checkOverlap(Player player, AI ghost) {
		int playerX = player.getX()+5, playerY = player.getY()+5;
		int ghostX = ghost.getX()+5, ghostY = ghost.getY()+5;
		int width = 26;
		if((playerX >= ghostX && playerX <= ghostX+width) && (playerY >= ghostY && playerY <= ghostY+width) ) {
			return true;
		}
		else if((playerX+width >= ghostX && playerX+width <= ghostX+width) && (playerY+width >= ghostY && playerY+width <= ghostY+width) ) {
			return true;
		}
		return false;
	}
	
	private void updateScores() {
		String temp1 = "00000"+playerList[0].getScore();
		String temp2 = "00000"+playerList[1].getScore();
		String p1Score = temp1.substring(temp1.length()-5);
		String p2Score = temp2.substring(temp2.length()-5);
		player1ScoreDisplay.setText(p1Score);
		player2ScoreDisplay.setText(p2Score);
	}
}
