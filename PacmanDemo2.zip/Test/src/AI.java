import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class AI extends GameClock{

	private char[] moveList = {'w', 'a', 's', 'd'};
	private String pDir = "up", sDir = "up";
	String  name;
	private boolean[] horizontalList, verticalList;
	private int x = 252, y = 260, oldX = -1, oldY = -1, xSpeed = 0, ySpeed = 0;
	JLabel ghostLabel;
	private Player[] playerList;
	
	AI(JLabel iJLabel, String imageFilePath, String iName, Player[] iPlayerList){
		playerList = iPlayerList;
		name = iName;
		ghostLabel = iJLabel;
		try {
			ghostLabel.setIcon(new ImageIcon(ImageIO.read(new File(imageFilePath))));
		} catch (Exception ex) {}
	}
	
	public void move() {
		updateVerticalList();
    	updateHorizontalList();
 		int i = -1;
 		if(sDir == "up" || sDir == "down") {
 			do {
        		i += 1;
        		if(sDir == "up") {
        			ySpeed = -1;
        			updateVerticalList();
        			if(verticalList[i]) {
        				pDir = "up";
        				pickMovement("down");
        				y += ySpeed;
        			}
        		}
        		else if(sDir == "down" && x != 252) {
        			ySpeed = 1;
        			updateVerticalList();
        			if(verticalList[i]) {
        				pDir = "down";
        				pickMovement("up");
        				y += ySpeed;
        			}
        		}                		
        	}
        	while(verticalList[i] == false && i < verticalList.length-1);
 		}
 		else if(sDir == "left" || sDir == "right") {
 			do {
        		i += 1;
        		if(sDir == "left") {
        			xSpeed = -1;
        			updateHorizontalList();
        			if(horizontalList[i]) {
        				pDir = "left";
        				pickMovement("right");
        				x += xSpeed;
        			}
        		}
        		else if(sDir == "right") {
        			xSpeed = 1;
        			updateHorizontalList();
        			if(horizontalList[i]) {
        				pDir = "right";
        				pickMovement("left");
        				x += xSpeed;
        			}
        		}
        	}
        	while(horizontalList[i] == false && i < horizontalList.length-1);
 		}
 		i = -1;
 		if(pDir == "up" || pDir == "down") {
 			do {
        		i += 1;
        		if(pDir == "up") {
        			ySpeed = -1;
        			updateVerticalList();
        			if(verticalList[i]) {
        				y += ySpeed;
        			}
        		}
        		else if(pDir == "down" && x != 252) {
        			ySpeed = 1;
        			updateVerticalList();
        			if(verticalList[i]) {
        				y += ySpeed;
        			}
        		}
        	}
        	while(verticalList[i] == false && i < verticalList.length-1);
 		}
 		else if(pDir == "left" || pDir == "right") {
 			do {
        		i += 1;
        		if(pDir == "left") {
        			xSpeed = -1;
        			updateHorizontalList();
        			if(horizontalList[i]) {
        				x += xSpeed;
        			}
        		}
        		else if(pDir == "right") {
        			xSpeed = 1;
        			updateHorizontalList();
        			if(horizontalList[i]) {
        				x += xSpeed;
        			}
        		}
        	}
        	while(horizontalList[i] == false && i < horizontalList.length-1);
 		}
 		if(oldX == x && (pDir == "left" || pDir == "right")) {
			if(sDir == "up") {
				sDir = "down";
			}
			else if(sDir == "down") {
				sDir = "up";
			}
			else {
				int random = (int)(Math.random()*100)+1;
				if(random < 50)
					sDir = "up";
				if(random >= 50)
					sDir = "down";
			}
		}
 		else if(oldY == y && (pDir == "down" || pDir == "up")) {
			if(sDir == "left") {
				sDir = "right";
			}
			else if(sDir == "right") {
				sDir = "left";
			}
			else {
				int random = (int)(Math.random()*100)+1;
				if(random < 50)
					sDir = "right";
				if(random >= 50)
					sDir = "left";
			}
		}
 		if(x == 0 && y == 261) {
 			x = 502;
    	}
    	else if(x==503 && y == 261) {
    		x = 1;
    	}
 		oldX = x;
 		oldY = y;
        ghostLabel.setLocation(x, y);
	}
	
	private void pickMovement(String iDir) {
		int random = (int)(Math.random()*100)+1;
		if(random < 90-(getDifficulty()*6)) {
			randomMove(iDir);
		}
		else {
			calculatedMove();
		}
	}
	
	private void randomMove(String iDir) {
		String tempDir = "";
		do {
			int random = (int)(Math.random()*100)+1;
			if(random< 25)
				tempDir = "up";
			if(random >= 25 && random < 50)
				tempDir = "left";
			if(random >= 50 && random < 75)
				tempDir = "down";
			if(random >= 75)
				tempDir = "right";
		}
		while(tempDir.equals(iDir));
		sDir = tempDir;
	}
	
	private void calculatedMove() {
		int random;
		if(!playerList[0].isAlive()) {
			random = 1;
		}
		else if(!playerList[1].isAlive()) {
			random = 0;
		}
		else {
			random = (int)(Math.random()*2);
		}
		int playerX = playerList[random].getX();
		int playerY = playerList[random].getY();
		String ver = "", hor = "";
		if(playerX < x) {
			if(pDir == "up" || pDir == "down")
				sDir = "left";
		}
		else if(playerX > x){
			if(pDir == "up" || pDir == "down")
				sDir = "right";
		}
		else {
			sDir = "none";
		}
		if(playerY < y) {
			if(pDir == "right" || pDir == "left")
				sDir = "up";
		}
		else if(playerY > y){
			if(pDir == "right" || pDir == "left")
				sDir = "down";
		}
		else {
			sDir = "none";
		}
	}
	
	private void updateHorizontalList() {
    	horizontalList = new boolean[]{(x+xSpeed>=10 && x+xSpeed<=223 && y==10),
    								   (x+xSpeed>=281 && x+xSpeed<=493 && y==10),
    								   (x+xSpeed>=10 && x+xSpeed<=493 && y==87),
    								   (x+xSpeed>=10 && x+xSpeed<=106 && y==145),
    								   (x+xSpeed>=396 && x+xSpeed<=493 && y==145),
    								   (x+xSpeed>=165 && x+xSpeed<=223 && y==145),
    								   (x+xSpeed>=281 && x+xSpeed<=339 && y==145),
    								   (x+xSpeed>=165 && x+xSpeed<=339 && y==203),
    								   (x+xSpeed>=0 && x+xSpeed<=165 && y==261),
    								   (x+xSpeed>=339 && x+xSpeed<=503 && y==261),
    								   (x+xSpeed>=165 && x+xSpeed<=339 && y==319),
    								   (x+xSpeed>=10 && x+xSpeed<=223 && y==377),
    								   (x+xSpeed>=281 && x+xSpeed<=493 && y==377),
    								   (x+xSpeed>=10 && x+xSpeed<=47 && y==435),
    								   (x+xSpeed>=453 && x+xSpeed<=493 && y==435),
    								   (x+xSpeed>=106 && x+xSpeed<=396 && y==435),
    								   (x+xSpeed>=10 && x+xSpeed<=106 && y==493),
    								   (x+xSpeed>=396 && x+xSpeed<=493 && y==493),
    								   (x+xSpeed>=165 && x+xSpeed<=223 && y==493),
    								   (x+xSpeed>=281 && x+xSpeed<=339 && y==493),
    								   (x+xSpeed>=10 && x+xSpeed<=493 && y==550)};
    }
	
	private void updateVerticalList() {
    	verticalList = new boolean[]{(y+ySpeed>=10 && y+ySpeed<=145 && x==10),
    								 (y+ySpeed>=377 && y+ySpeed<=435 && x==10),
    								 (y+ySpeed>=493 && y+ySpeed<=550 && x==10),
    								 (y+ySpeed>=435 && y+ySpeed<=493 && x==47),
    								 (y+ySpeed>=10 && y+ySpeed<=493 && x==106),
    								 (y+ySpeed>=87 && y+ySpeed<=145 && x==165),
    								 (y+ySpeed>=203 && y+ySpeed<=377 && x==165),
    								 (y+ySpeed>=435 && y+ySpeed<=493 && x==165),
    								 (y+ySpeed>=10 && y+ySpeed<=87 && x==223),
    								 (y+ySpeed>=145 && y+ySpeed<=203 && x==223),
    								 (y+ySpeed>=377 && y+ySpeed<=435 && x==223),
    								 (y+ySpeed>=493 && y+ySpeed<=550 && x==223),
    								 (y+ySpeed>=203 && y+ySpeed<=260 && x==252),
    								 (y+ySpeed>=10 && y+ySpeed<=87 && x==281),
    								 (y+ySpeed>=145 && y+ySpeed<=203 && x==281),
    								 (y+ySpeed>=377 && y+ySpeed<=435 && x==281),
    								 (y+ySpeed>=493 && y+ySpeed<=550 && x==281),
    								 (y+ySpeed>=87 && y+ySpeed<=145 && x==339),
    								 (y+ySpeed>=203 && y+ySpeed<=377 && x==339),
    								 (y+ySpeed>=435 && y+ySpeed<=493 && x==339),
    								 (y+ySpeed>=10 && y+ySpeed<=493 && x==396),
    								 (y+ySpeed>=435 && y+ySpeed<=493 && x==453),
    								 (y+ySpeed>=10 && y+ySpeed<=145 && x==493),
    								 (y+ySpeed>=377 && y+ySpeed<=435 && x==493),
    								 (y+ySpeed>=493 && y+ySpeed<=550 && x==493)};
    }
	
	public String toString() {
		return name;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
}
