import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.swing.JLabel;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class AnimationUpdater extends GameClock{
	
	private Thread Updater = new Thread(new updater(), "Animation Updater");
	private Player player1;
	private Player player2;
	private File ghostsFolder = new File("images/Ghosts");
	private File explosionFolder = new File("images/Explosion");
	private File pacmanDeathFolder = new File("images/PacmanDeath");
	private File pacmanEatingFolder = new File("images/PacmanEating");
	private boolean gameOverCheck = true;
	private JLabel jGameOverDisplay;
	
	AI[] ghostList;
	
	AnimationUpdater(Player[] iPlayerList, AI[] iGhostList, JLabel JGameOverDisplay){
		jGameOverDisplay = JGameOverDisplay;
		ghostList = iGhostList;
		player1 = iPlayerList[0];
		player2 = iPlayerList[1];
		Updater.start();
	}
	
	public class updater implements Runnable{
		@Override
		public void run() {
			while(true) {
				if(!player1.isAlive() && player1.playerLabel.isVisible() == true) {
					PlayerDeathAnimation(player1);
				}
				
				if(!player2.isAlive() && player2.playerLabel.isVisible() == true) {
					PlayerDeathAnimation(player2);
				}
				
				for(File file: pacmanEatingFolder.listFiles()) {
					if(player1.isAlive()) {
						player1.playerLabel.setIcon(getImage(file, player1.getPDir(), player1.getSDir()));
					}
					if(player2.isAlive()) {
						player2.playerLabel.setIcon(getImage(file, player2.getPDir(), player2.getSDir()));
					}
					try {
						Thread.sleep(50);
					}
					catch(Exception ex) {System.out.println(ex);}
					if((!player2.isAlive() && !player2.playerLabel.isVisible()) &&
					   (!player1.isAlive() && !player1.playerLabel.isVisible())) {
						break;
					}
				}
				if(isGameOver() && gameOverCheck) {
					GhostsDeathAnimations();
					jGameOverDisplay.setVisible(true);
				}
			}
		}
	}
	
	public void GhostsDeathAnimations() {
		for(AI ghost : ghostList) {
			for(File file : explosionFolder.listFiles()) {
				ImageIcon image = null;
				try {
					Thread.sleep(100);
					image = new ImageIcon(ImageIO.read(file));
				}
				catch(Exception ex) {}
				ghost.ghostLabel.setIcon(image);
			}
		}
		gameOverCheck = false;
	}
	
	public void PlayerDeathAnimation(Player player) {
		for(File file: pacmanDeathFolder.listFiles()) {
			try {
				Thread.sleep(50);
			}
			catch(Exception ex) {System.out.println(ex);}
			player.playerLabel.setIcon(getImage(file, player.getPDir(), player.getSDir()));
		}
		player.playerLabel.setVisible(false);
	}
	
	public ImageIcon getImage(File file, String pDir, String sDir){
		BufferedImage bImage = null;
		double num = 0;
		try {
			bImage = ImageIO.read(file);
		}
		catch(Exception ex) {}
		switch(sDir) {
		case("up"):
			num = 1.5;
			break;
		case("down"):
			num = 0.5;
			break;
		case("right"):
			num = 0;
			break;
		case("left"):
			num = 1;
			break;
		case("none"):
			switch(pDir) {
			case("up"):
				num = 1.5;
				break;
			case("down"):
				num = 0.5;
				break;
			case("right"):
				num = 0;
				break;
			case("left"):
				num = 1;
				break;
			}
			break;
		}
		bImage = rotateImage(bImage, num);
		return new ImageIcon(bImage);
	}
	
	public static BufferedImage rotateImage(BufferedImage src, double num) {
	    int width = 36;
	    int height = 36;
	    
	    BufferedImage dest = new BufferedImage(height, width, src.getType());

	    Graphics2D graphics2D = dest.createGraphics();
	    graphics2D.rotate(Math.PI*num, height / 2, width / 2);
	    graphics2D.drawRenderedImage(src, null);
	    graphics2D.dispose();

	    return dest;
	}
}
