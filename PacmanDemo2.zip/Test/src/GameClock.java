import javax.swing.JLabel;

public class GameClock {
	
	private static Thread DifficultyScaler = new Thread(new difficultyScaler(), "Hitbox Checker");
	private static int difficulty = 0, endCount = 3;
	private static JLabel jClock;
	private static Player[] playerList;
	private static boolean gameOver = false;
	
	GameClock(JLabel iClock, Player[] iPlayerList){
		playerList = iPlayerList;
		jClock = iClock;
		DifficultyScaler.start();
	}
	
	GameClock(){
	}
	
	private static class difficultyScaler implements Runnable{
		@Override
		public void run() {
			int count = 0;
			while(true) {
				try {
					Thread.sleep(1000);
				}
				catch(Exception ex) {System.out.println(ex);}
				if(count<90 && (playerList[0].isAlive() || playerList[1].isAlive())) {
					jClock.setText("Timer: "+count);
					if(count%5 == 0) {
						if(difficulty+1 < 15) {
							difficulty += 1;
						}
					}
					count+=1;
					if(playerList[0].isAlive())
						playerList[0].addScore(difficulty*10);
					if(playerList[1].isAlive())
						playerList[1].addScore(difficulty*10);
				}
				else if (!gameOver){
					jClock.setText("");
					difficulty -= endCount;
					if(difficulty < -200) {
						gameOver = true;
					}
					endCount *= 2;
				}
			}
		}
	}
	
	public static int getDifficulty() {
		return difficulty;
	}
	
	public static boolean isGameOver() {
		return gameOver;
	}
}

