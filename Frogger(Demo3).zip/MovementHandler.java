import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
	
/**
 * The Class MovementHandler.
 */
//THIS CLASS WILL HANDLE ALL MOVEMENT INCLUDING: PLAYERS, LANES, BUSES
public class MovementHandler {
	
	/** The rate of descent. */
	//integer rate that the map and everything on it will move at
	final int slowDescent = 1;
	
	/** Start the Bus thread. */
	//create the bus movement thread
	Thread BusThread = new Thread(new BusThread());
	
	/** The Bus list 1. */
	//create the bus list
	private Obstacle BusList1[] = new Obstacle[13];
	
	/** The Player list 1. */
	//create the player list
	private Player PlayerList1[] = new Player[5];
	
	/** The Lane list 1. */
	//create the lane list
	private Lane LaneList1[] = new Lane[13];
	
	/** The background. */
	//create the background
	JLabel background;
	
	/** Create the player 1,2,3,4, JLabels. */
	private JLabel player1ShowScore, player2ShowScore, player3ShowScore, player4ShowScore;
	
	/**
	 * Instantiates a new movement handler.
	 *
	 * @param b the obstacle list
	 * @param p the player list
	 * @param o the the background
	 * THESE HAVE NOT BEEN FULLY IMPLEMENTED YET
	 * @param iPlayer1ShowScore the i player 1 show score <
	 * @param iPlayer2ShowScore the i player 2 show score <
	 * @param iPlayer3ShowScore the i player 3 show score <
	 * @param iPlayer4ShowScore the i player 4 show score <
	 */
	//constructor that copies over player, bus and lane lists to be updated for movement
	public MovementHandler(Obstacle[] b, Player[] p, JLabel o, JLabel iPlayer1ShowScore, JLabel iPlayer2ShowScore, JLabel iPlayer3ShowScore, JLabel iPlayer4ShowScore) {
		player1ShowScore = iPlayer1ShowScore;
		player2ShowScore = iPlayer2ShowScore;
		player3ShowScore = iPlayer3ShowScore;
		player4ShowScore = iPlayer4ShowScore;
		BusList1 = b;
		PlayerList1 = p;
		background = o;
		BusThread.start();
	}
	
	/**
	 * The Class BusThread.
	 */
	//thread that handles all movement
	public class BusThread implements Runnable{
		
		/**
		 * Run.
		 */
		@Override
		public void run(){
			while(true) {
				try {
					Thread.sleep(20);
				}
				catch(Exception ex) {};

				//nested loop to check for player bus collisions
				for (Obstacle bus : BusList1) {
					for (Player player : PlayerList1) {
						if(Intersects.Intersect(player, bus)) {
							player.respawn();        //THIS METHOD WILL BE REPLACED WITH LANE ACCURATE RESPAWN POSITIONING LATER 
						}							 //MAKING USE OF THE LANE CLASS
					}
				}	
				
				//Move the background
				background.setLocation(background.getX(), background.getY() + slowDescent);
				
				
				//move the players
				PlayerList1[0].setLocation(PlayerList1[0].getX(), PlayerList1[0].getY() + slowDescent);
				PlayerList1[1].setLocation(PlayerList1[1].getX(), PlayerList1[1].getY() + slowDescent);
				PlayerList1[2].setLocation(PlayerList1[2].getX(), PlayerList1[2].getY() + slowDescent);
				PlayerList1[3].setLocation(PlayerList1[3].getX(), PlayerList1[3].getY() + slowDescent);
				
				
				//move the buses
		
				
				//1
				BusList1[0].setLocation(BusList1[0].getX()-2, BusList1[0].getY()+ slowDescent);
				BusList1[0].resetRight();
				
				//2
				BusList1[1].setLocation(BusList1[1].getX()+7, BusList1[1].getY()+ slowDescent);
				BusList1[1].resetLeft();
				
				//3
				BusList1[2].setLocation(BusList1[2].getX()+2, BusList1[2].getY()+ slowDescent);
				BusList1[2].resetLeft();
				
				//4
				BusList1[3].setLocation(BusList1[3].getX()+3, BusList1[3].getY()+ slowDescent);
				BusList1[3].resetLeft();
				
				
				//5
				BusList1[4].setLocation(BusList1[4].getX()-2, BusList1[4].getY()+ slowDescent);
				BusList1[4].resetRight();
				
				
				//6
				BusList1[5].setLocation(BusList1[5].getX()-2, BusList1[5].getY()+ slowDescent);
				BusList1[5].resetRight();
				
				
				//7
				BusList1[6].setLocation(BusList1[6].getX()-2, BusList1[6].getY()+ slowDescent);
				BusList1[6].resetRight();

				//8
				BusList1[7].setLocation(BusList1[7].getX()+2, BusList1[7].getY()+ slowDescent);
				BusList1[7].resetLeft();
				
				
				//9
				BusList1[8].setLocation(BusList1[8].getX()+2, BusList1[8].getY()+ slowDescent);
				BusList1[8].resetLeft();
				
				//10
				BusList1[9].setLocation(BusList1[9].getX()-2, BusList1[9].getY()+ slowDescent);
				BusList1[9].resetRight();
		
				//11
				BusList1[10].setLocation(BusList1[10].getX()-2, BusList1[10].getY()+ slowDescent);
				BusList1[10].resetRight();
				
				//12
				BusList1[11].setLocation(BusList1[11].getX()-2, BusList1[11].getY()+ slowDescent);
				BusList1[11].resetRight();
																								
				
			}
		}
	}
	
	/**
	 * Update scores.
	 */
	//update the scores
	private void updateScores() {
		String temp1 = "00000"+PlayerList1[0].getScore();
		String temp2 = "00000"+PlayerList1[1].getScore();
		String temp3 = "00000"+PlayerList1[2].getScore();
		String temp4 = "00000"+PlayerList1[3].getScore();
		String p1Score = temp1.substring(temp1.length()-5);
		String p2Score = temp2.substring(temp2.length()-5);
		String p3Score = temp3.substring(temp3.length()-5);
		String p4Score = temp4.substring(temp4.length()-5);
		player1ShowScore.setText(p1Score);
		player2ShowScore.setText(p2Score);
		player3ShowScore.setText(p3Score);
		player4ShowScore.setText(p4Score);
	}
}


