import java.awt.event.ActionEvent;

import javax.swing.JLabel;

//Handles Phidget Handler movement for players
/**
 * The Class PhidgetHandler.
 */
//connects the GUI movement to the Phidget Handler Super keys 
public class PhidgetHandler extends PhidgetHandlerSuper{
	
	/** The player 1 label. */
	private JLabel player1Label;
	
	/** The player 2 label. */
	private JLabel player2Label;
	
	/** The player 3 label. */
	private JLabel player3Label;
	
	/** The player 4 label. */
	private JLabel player4Label;
	
	/**
	 * Instantiates a new phidget handler.
	 *
	 * @param playerList the player list
	 */
	//get the labels for the players and add movement using keys
	PhidgetHandler(Player[] playerList){
		player1Label = playerList[0].getLabel();
		player2Label = playerList[1].getLabel();
		player3Label = playerList[2].getLabel();
		player4Label = playerList[3].getLabel();
		
	}

	
	/**
	 * Player one action.
	 */
	//movement for player 1 using keys and GUI
	@Override
	public void playerOneAction() {
		player1Label.setLocation(player1Label.getX(), player1Label.getY()-50);
		
	}

	
	/**
	 * Player two action.
	 */
	//movement for player 2 using keys and GUI
	@Override
	public void playerTwoAction() {
		player2Label.setLocation(player2Label.getX(), player2Label.getY()-50);
		
	}

	
	/**
	 * Player three action.
	 */
	//movement for player 3 using keys and GUI
	@Override
	public void playerThreeAction() {
		player3Label.setLocation(player3Label.getX(), player3Label.getY()-50);
		
	}

	
	/**
	 * Player four action.
	 */
	//movement for player 4 using keys and GUI
	@Override
	public void playerFourAction() {
		player4Label.setLocation(player4Label.getX(), player4Label.getY()-50);
		
	}
}
