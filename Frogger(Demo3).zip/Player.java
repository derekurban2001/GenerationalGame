import javax.swing.JLabel;

/**
 * The Class Player.
 */
//THIS CLASS IS A TEMPLATE FOR PLAYERS
public class Player{
	//player instance variables
	
	/** The player JLabel. */
	private JLabel label;
	
	/** The player score. */
	private int score;
	
	/**
	 * Instantiates a new player.
	 *
	 * @param p the player JLabel
	 * @param s the player score
	 */
	//constructor to give associate a score with a JLabel
	public Player(JLabel p, int s) {
		label = p;
		score = s;
	}
	
	/**
	 * Gets the label.
	 *
	 * @return the label
	 */
	//getters for x, and score
	public JLabel getLabel() {
		return label;
	}
	
	/**
	 * Gets the player x coordinate
	 *
	 * @return the x coordinate
	 */
	public int getX() {
		return label.getX();
	}
	
	/**
	 * Gets the player y coordinate
	 *
	 * @return the y coordinate
	 */
	public int getY() {
		return label.getY();
	}
	
	/**
	 * Gets the width.
	 *
	 * @return the width
	 */
	public int getWidth() {
		return label.getWidth();
	}
	
	/**
	 * Gets the height.
	 *
	 * @return the height
	 */
	public int getHeight() {
		return label.getHeight();
	}
	
	
	//setters for x,y and score
	//length and width never change so they do not require setters
	
	/**
	 * Sets the location.
	 *
	 * @param a the x coordinate
	 * @param b the y coordinate
	 */
	public void setLocation(int a, int b) {
		label.setLocation(a,b);
	}
	
	/**
	 * Respawn method for players
	 * 
	 * NOT FULLY IMPLEMENTED YET
	 * RIGHT NOW IT RESPAWNS PLAYERS TO A FIXED POINT ON THE SCREEN (468)
	 * BUT IT WILL EVENTUALLY RESPAWN THEM BASED ON HOW FAR THEY GET IN THE MAP 
	 * (THEY RESPAWN BACK TO THE NEAREST SAFEZONE THEY PASSED)
	 * 
	 */
	//method for respawning the players every time they hit an obstacle or are behind the map speed
	public void respawn() {
		label.setLocation(label.getX(), 468);
	}
	
	/**
	 * Sets the score.
	 *
	 * @param s the new score
	 */
	public void setScore(int s) {
		this.score = s;
	}
	
	/**
	 * Gets the score.
	 *
	 * @return the score
	 */
	public int getScore() {
		return score;
	}
	
	/**
	 * Adds the score.
	 *
	 * @param num the score to add
	 */
	public void addScore(int num) {
		score += num;
	}
	
	/**
	 * Subtract score.
	 *
	 * @param num the score to subtract
	 */
	public void subtractScore(int num) {
		this.score -= num;
	}
	
}
