//package superclasses; Meant for final copy
//import static pixelpartymenu.CoreFrame.contentPane; Meant for final copy

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.KeyStroke;

// TODO: Auto-generated Javadoc
//handles phidget player moving with:
//key  Q for playerone
//key R for playertwo
//key U for playerthree
//key P for playerfour

/**
 * The Class PhidgetHandlerSuper.
 */
public abstract class PhidgetHandlerSuper{
	
	/** The Constant PLAYER_ONE. */
	private static final String PLAYER_ONE = "playerOne";
	
	/** The Constant PLAYER_TWO. */
	private static final String PLAYER_TWO = "playerTwo";
	
	/** The Constant PLAYER_THREE. */
	private static final String PLAYER_THREE = "playerThree";
	
	/** The Constant PLAYER_FOUR. */
	private static final String PLAYER_FOUR = "playerFour";
	
	/** The i map. */
	private static InputMap iMap;
	
	/** The a map. */
	private static ActionMap aMap;
	
	/**
	 * Instantiates a new phidget handler super.
	 */
	protected PhidgetHandlerSuper(){
		addKeyBind("Q", "playerOne", playerOnePerformAction);
		addKeyBind("R", "playerTwo", playerTwoPerformAction);
		addKeyBind("U", "playerThree", playerThreePerformAction);
		addKeyBind("P", "playerFour", playerFourPerformAction);
	}
	
	/**
	 * Player one action.
	 */
	public abstract void playerOneAction();
	
	/**
	 * Player two action.
	 */
	public abstract void playerTwoAction();
	
	/**
	 * Player three action.
	 */
	public abstract void playerThreeAction();
	
	/**
	 * Player four action.
	 */
	public abstract void playerFourAction();
	
	/**
	 * Adds the key bind.
	 *
	 * @param key the key
	 * @param playerConstant the player constant
	 * @param act the act
	 */
	private void addKeyBind(String key, String playerConstant, Action act) {
		//replace contentPane with a static JFrame or JPanel from the main class of your program.
		//For example, if you have a contentPane in your GUI.java class, initialize the contentPane as
		//static, then use <GUI.contentPane> to replace.
	    iMap = GUI.contentPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
	    aMap = GUI.contentPane.getActionMap();
	    iMap.put(KeyStroke.getKeyStroke(key), playerConstant);
	    aMap.put(playerConstant, act);
	}
	
	/** The player one perform action. */
	Action playerOnePerformAction = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {
			playerOneAction();
		}
	};
	
	/** The player two perform action. */
	Action playerTwoPerformAction = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {
			playerTwoAction();
		}
	};
	
	/** The player three perform action. */
	Action playerThreePerformAction = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {
			playerThreeAction();
		}
	};
	
	/** The player four perform action. */
	Action playerFourPerformAction = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {
			playerFourAction();
		}
	};
}
