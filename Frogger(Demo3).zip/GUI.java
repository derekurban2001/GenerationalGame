import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.border.MatteBorder;
import javax.swing.JSeparator;
import javax.swing.border.CompoundBorder;
import javax.swing.JFrame;

/**
 * The Class GUI.
 */
public class GUI extends JFrame {

	/** The Background. */
	//create the Jlabel background background
	private JLabel Background = new JLabel("");

	/** The the total score. */
	//num to subtract from to find score
	private int num = 15;
	
	/** The Bus list. */
	//create the bus list
	private Obstacle BusList[] = new Obstacle[12];
	
	/** The Player list. */
	//create the player list
	private Player PlayerList[] = new Player[4];
	
	/** The Lane list. */
	//create the lane list
	private Lane LaneList[] = new Lane[13];
	
	/** The x and y starting coordinates for the buses */
								//1  2  3    4    5    6     7   8   9   10  11  12
	private final int xBus[] = {269, 55, 514, 514, 269, 532, 269, 55, 55, 269, 0, 0};
	private final int yBus[] = {395, 386, 386, 284, 284, 197, 197, 284, 197, 99, 99, 70};
	
	
	/** The content pane. */
	public static JPanel contentPane;
	
	
	/** The j player 1,2,3,4 labels. */
	private JLabel jPlayer1Label = new JLabel("Player1");
	private JLabel jPlayer2Label = new JLabel("Player2");
	private JLabel jPlayer3Label = new JLabel("Player3");
	private JLabel jPlayer4Label = new JLabel("Player 4");
	
	/** create the players 1,2,3,4 and give them Jlabels */
	private Player player1 = new Player(jPlayer1Label, 0);
	private Player player2 = new Player(jPlayer2Label, 0);
	private Player player3 = new Player(jPlayer3Label, 0);
	private Player player4 = new Player(jPlayer4Label, 0);
	
	/** Create the lanes */
	//THIS HAS NOT BEEN IMPLEMENTED YET 
	private Lane lane1 = new Lane(0);
	private Lane lane2 = new Lane(0);
	private Lane lane3 = new Lane(0);
	private Lane lane4 = new Lane(0);
	private Lane lane5 = new Lane(0);
	private Lane lane6 = new Lane(0);
	private Lane lane7 = new Lane(0);
	private Lane lane8 = new Lane(0);
	private Lane lane9 = new Lane(0);
	private Lane lane10 = new Lane(0);
	private Lane lane11 = new Lane(0);
	private Lane lane12 = new Lane(0);
	private Lane lane13 = new Lane(0);
	
	/**
	 * Launch the application.
	 *
	 * @param args the arguments
	 */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
//thread that checks for intersections between players and buses
public class runThingy implements Runnable{
		@Override
		public void run(){
			while(true) {
				try {
					Thread.sleep(10);
				}
				catch(Exception ex) {};
				
				for (Obstacle bus : BusList) {						//for every bus
					for (Player player : PlayerList) {				//for every player
						if(Intersects.Intersect(player, bus)){		//if they intersect
							player.respawn();							//kill the player
							player.subtractScore(num);				//subtract one from their score (NOT IMPLEMENTED YET)
						}
					}
				}
			}
		}
	}
	
	
	/**
	 * Create the frame.
	 */
	//create constructors where we store labels, movement handler, phidget handler
	public GUI() {
		
		initComponents();
		
		//fill the player list with players
		PlayerList[0] = player1; PlayerList[1] = player2; 
		PlayerList[2] = player3; PlayerList[3] = player4;
		
		//fill the lane list with lanes
		LaneList[0] = lane1; LaneList[1] = lane2; LaneList[2] = lane3; LaneList[3] = lane4;
		LaneList[4] = lane5; LaneList[5] = lane6; LaneList[6] = lane7; LaneList[7] = lane8;
		LaneList[8] = lane9; LaneList[9] = lane10; LaneList[10] = lane11; LaneList[11] = lane12;
		LaneList[12] = lane13;
		
		//add the player 1 to the window
		jPlayer1Label.setBorder(new LineBorder(Color.RED));
		jPlayer1Label.setFont(new Font("Tahoma", Font.BOLD, 11));
		jPlayer1Label.setForeground(Color.PINK);
		jPlayer1Label.setBounds(70, 440, 50, 47);
		contentPane.add(jPlayer1Label);
		jPlayer2Label.setForeground(Color.WHITE);
		
		//add the player 2 to the window
		jPlayer2Label.setBorder(new MatteBorder(1, 1, 1, 1, (Color) Color.PINK));
		jPlayer2Label.setBounds(212, 440, 50, 47);
		contentPane.add(jPlayer2Label);
		jPlayer3Label.setForeground(Color.WHITE);
		
		//add the player 3 to the window
		jPlayer3Label.setBorder(new LineBorder(Color.GREEN));
		jPlayer3Label.setBounds(378, 440, 50, 47);
		contentPane.add(jPlayer3Label);
		jPlayer4Label.setForeground(Color.WHITE);
		
		//add the player 4 to the window
		jPlayer4Label.setBorder(new MatteBorder(1, 1, 1, 1, (Color) Color.MAGENTA));
		jPlayer4Label.setBounds(553, 440, 50, 47);
		contentPane.add(jPlayer4Label);
		
		
		//add the buses to the window
		for(int i = 0; i<12;i++) {
			BusList[i] = createObstacle(xBus[i], yBus[i]);
		}
		
		//start the bus movement thread
		//new MovementHandler(BusList, PlayerList, Background, jPlayer1Label, jPlayer2Label, jPlayer3Label, jPlayer4Label);
		
		//add background to the panel
		contentPane.add(Background);
		
		//use the playerlist to call on every player to phidget handler
		new PhidgetHandler(PlayerList);
	}
		
	//adding the buses to the window
	/**
	 * Creates the obstacle.
	 *
	 * @param x the starting x-coordinate
	 * @param y starting x-coordinate
	 * @return the obstacle
	 */
	//create jLabels for every obstacle so this code is used for every label without repetition
	public Obstacle createObstacle(int x, int y) {
		JLabel label = new JLabel();							//create the bus Jlabel
		label.setHorizontalAlignment(SwingConstants.CENTER);	//set the bus horizontal alignment
		label.setBorder(new LineBorder(Color.WHITE, 5));		//set the temporary line border for the bus (to be replaced with a picture later)
		label.setBounds(x, y, 90, 40);							//set the pixel dimensions for the bus
		contentPane.add(label);									//add the Jlabel to the window
		return new Obstacle(label);								//return the completed bus to the Jlabel list
	}
	
	/**
	 * Inits the components.
	 */
	//create components for the panel
	private void initComponents() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 667, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
				
				//add the background image
				Background.setHorizontalAlignment(SwingConstants.CENTER);
				Background.setFont(new Font("Tahoma", Font.BOLD, 66));
				Background.setIcon(new ImageIcon("C:\\Users\\David\\eclipse-workspace\\CR6\\src\\Background6.png"));
				Background.setBounds(0, -1700, 667, 2380);
				
				//add the player score displays
				JLabel player1ShowScore = new JLabel("Player 1 Score:");
				player1ShowScore.setHorizontalAlignment(SwingConstants.CENTER);
				player1ShowScore.setForeground(Color.WHITE);
				player1ShowScore.setFont(new Font("Algerian", Font.BOLD, 18));
				player1ShowScore.setBounds(0, -8, 162, 41);
				contentPane.add(player1ShowScore);
				
				JLabel player1ShowScore1 = new JLabel("00000");
				player1ShowScore1.setHorizontalAlignment(SwingConstants.CENTER);
				player1ShowScore1.setForeground(Color.WHITE);
				player1ShowScore1.setFont(new Font("Algerian", Font.BOLD, 18));
				player1ShowScore1.setBounds(34, 28, 92, 26);
				contentPane.add(player1ShowScore1);
				
				JLabel player2ShowScore = new JLabel("Player 2 Score:");
				player2ShowScore.setHorizontalAlignment(SwingConstants.CENTER);
				player2ShowScore.setFont(new Font("Algerian", Font.BOLD, 18));
				player2ShowScore.setForeground(Color.WHITE);
				player2ShowScore.setBounds(160, 0, 156, 24);
				contentPane.add(player2ShowScore);
				
				JLabel player2ShowScore1 = new JLabel("00000");
				player2ShowScore1.setHorizontalAlignment(SwingConstants.CENTER);
				player2ShowScore1.setFont(new Font("Algerian", Font.BOLD, 18));
				player2ShowScore1.setForeground(Color.WHITE);
				player2ShowScore1.setBounds(193, 28, 92, 26);
				contentPane.add(player2ShowScore1);
				
				JLabel player3ShowScore = new JLabel("Player 3 Score:");
				player3ShowScore.setHorizontalAlignment(SwingConstants.CENTER);
				player3ShowScore.setFont(new Font("Algerian", Font.BOLD, 18));
				player3ShowScore.setForeground(Color.WHITE);
				player3ShowScore.setBounds(326, 0, 156, 24);
				contentPane.add(player3ShowScore);
				
				JLabel player3ShowScore1 = new JLabel("00000");
				player3ShowScore1.setHorizontalAlignment(SwingConstants.CENTER);
				player3ShowScore1.setFont(new Font("Algerian", Font.BOLD, 18));
				player3ShowScore1.setForeground(Color.WHITE);
				player3ShowScore1.setBounds(362, 28, 92, 26);
				contentPane.add(player3ShowScore1);
				
				JLabel player4ShowScore = new JLabel("Player 4 Score:");
				player4ShowScore.setHorizontalAlignment(SwingConstants.CENTER);
				player4ShowScore.setFont(new Font("Algerian", Font.BOLD, 18));
				player4ShowScore.setForeground(Color.WHITE);
				player4ShowScore.setBounds(495, 0, 159, 24);
				contentPane.add(player4ShowScore);
				
				JLabel player4ShowScore1 = new JLabel("00000");
				player4ShowScore1.setHorizontalAlignment(SwingConstants.CENTER);
				player4ShowScore1.setFont(new Font("Algerian", Font.BOLD, 18));
				player4ShowScore1.setForeground(Color.WHITE);
				player4ShowScore1.setBounds(530, 28, 92, 26);
				contentPane.add(player4ShowScore1);
				
				new MovementHandler(BusList, PlayerList, Background, player1ShowScore1, player2ShowScore1, player3ShowScore1, player4ShowScore1);
				
				
	}
	
	/**
	 * Gets the background.
	 *
	 * @return the background
	 */
	public JLabel getbackground() {
		return Background;
	}
	
	
}