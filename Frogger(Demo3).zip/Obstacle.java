import javax.swing.JLabel;

// TODO: Auto-generated Javadoc
/**
 * The Class Obstacle.
 */
//THIS CLASS IS A TEMPLATE FOR ANY OBSTACLES THAT THE PLAYERS MIGHT ENCOUNTER
public class Obstacle {
	
	//instance variables
	
	/** The bus. */
	private JLabel bus;
	
	/** The starting x coordinate. */
	private int x;
	
	/** The starting y coordinate. */
	private int y;
	
	/** The width. */
	private int w;
	
	/** The height. */
	private int h;
	
	/**
	 * Instantiates a new obstacle.
	 *
	 * @param b the Bus JLabel
	 */
	//constructor to give associate a bus with a JLabel
	public Obstacle(JLabel b) {
		bus = b;
		x = b.getX();
		y = b.getY();
		w = b.getWidth();
		h = b.getHeight();
	}

	/**
	 * Gets the x coordinate
	 *
	 * @return the c coordinate
	 */
	//getters for x,y width, and height
	public int getX() {
		return bus.getX();
	}
	
	/**
	 * Gets the y coordinate
	 *
	 * @return the y coordinate
	 */
	public int getY() {
		return bus.getY();
	}
	
	/**
	 * Gets the width.
	 *
	 * @return the width
	 */
	public int getWidth() {
		return bus.getWidth();
	}
	
	/**
	 * Gets the height.
	 *
	 * @return the height
	 */
	public int getHeight() {
		return bus.getHeight();
	}
	
	/**
	 * Gets the label.
	 *
	 * @return the label
	 */
	public JLabel getLabel() {
		return bus;
	}
	
	/**
	 * Method to reset bus position to right of screen
	 */
	//method to reset bus position to the right side of the screen if it moves too far left
	public void resetRight() {
		if (bus.getX() + bus.getWidth() < -1) {
			bus.setLocation(668, bus.getY());
		}
	}
	
	/**
	 * Method to reset bus position to left of screen
	 */
	//method to reset bus position to the left side of the screen if it moves too far right
	public void resetLeft() {
		if (x > 668) {
			bus.setLocation(-w,y);
		}
	}
	
	/**
	 * Sets the location.
	 *
	 * @param x the x coordinate
	 * @param y the y coordinate
	 */
	//setter for bus location
	public void setLocation(int x, int y) {
		bus.setLocation(x, y);
	}
	
	
	
}
