import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * The Class CrossyRoadMainClass.
 */
//THIS CLASS IS A MAIN CLASS THAT THE GAME CAN BE RUN FROM TO MAKE IT EASIER TO BUNDLE ALL 3 GAMES TOGETHER
public class CrossyRoadMainClass {
	
	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	//GUI gui;
	public static void main(String[] args) {
		try {
			GUI gui = new GUI();
			JPanel panel = GUI.contentPane;
			JFrame frame = new JFrame();
			frame.setVisible(true);
			frame.setResizable(false);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setBounds(0, 0, 667, 598+28);
			panel.setVisible(true);
			frame.setContentPane(panel);
			frame.setLocationRelativeTo(null);
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
}
