import javax.swing.JLabel;

public class ObjectMovementHandler {
	private Thread Checker = new Thread(new checker(), "Hitbox Checker");
	
	Player playerList[];
	AI ghostList[];
	
	ObjectMovementHandler(Player[] iPlayerList, AI[] iGhostList){
		playerList = iPlayerList;
		ghostList = iGhostList;
		System.out.println("Starting Object Movement Handler Runnable...");
		Checker.start();
	}
	
	private class checker implements Runnable{
		@Override
		public void run() {
			while(true) {
				try {
					Thread.sleep(10);
				}
				catch(Exception ex) {System.out.println(ex);}
				
				for(Player player:playerList) {
					player.move();
				}
				
				for(AI ghost:ghostList) {
					ghost.move();
				}
				
				for(Player player:playerList) {
					for(AI ghost:ghostList) {
						if(checkOverlap(player, ghost)){
							System.out.println("Hitbox Overlap Detected...");
							System.out.println("Killing Player...");
							player.kill();
							System.out.println("Program Shutting Down due to Dead Player...");
							System.exit(0);
						}
					}
				}
			}
		}
	}
	
	public boolean checkOverlap(Player player, AI ghost) {
		int playerX = player.getX()+5, playerY = player.getY()+5;
		int ghostX = ghost.getX()+5, ghostY = ghost.getY()+5;
		int width = 26;
		if((playerX >= ghostX && playerX <= ghostX+width) && (playerY >= ghostY && playerY <= ghostY+width) ) {
			return true;
		}
		else if((playerX+width >= ghostX && playerX+width <= ghostX+width) && (playerY+width >= ghostY && playerY+width <= ghostY+width) ) {
			return true;
		}
		return false;
	}
}
