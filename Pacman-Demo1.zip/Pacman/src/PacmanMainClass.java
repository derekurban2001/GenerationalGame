import java.awt.EventQueue;

public class PacmanMainClass {
	public static void main(String[] args) {
		System.out.println("Program Launched...");
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
