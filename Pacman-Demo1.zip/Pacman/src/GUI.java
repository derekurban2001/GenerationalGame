import java.awt.BorderLayout;
import java.awt.*;
import java.awt.EventQueue;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.SwingConstants;


public class GUI extends JFrame {	
    private JTextField textField = new JTextField();
    private Player pacmanPlayer1;
    private Player pacmanPlayer2;
    private AI ghostAI1;
	
	public GUI() {
		System.out.println("Generating Board...");
	    JPanel panel;
	    JPanel contentPane;
	    JLabel pacmanLabel1;
	    JLabel ghostLabel1 = null;

	    
	    System.out.println("Adding Content Pane...");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 586, 636);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		System.out.println("Adding Panel...");
		panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setBounds(0, 0, 577, 604);
		contentPane.add(panel);
		panel.setLayout(null);
		
		System.out.println("Adding Pacman Label...");
		pacmanLabel1 = new JLabel("");
		pacmanLabel1.setBounds(10, 10, 36, 36);
		panel.add(pacmanLabel1);
		
		System.out.println("Generating ghost...");
		ghostAI1 = addGhost(ghostLabel1, panel, "ghostRed.png", "Red Ghost");
		System.out.println("Creating Player...");
		pacmanPlayer1 = new Player(pacmanLabel1, "Player 1");
		
		System.out.println("Creating Player List...");
		System.out.println("Creating Ghost List...");
		Player playerList[] = {pacmanPlayer1};
	    AI ghostList[] = {ghostAI1};
		
	    System.out.println("Calling Object Movement Handler...");
	    ObjectMovementHandler objectMovementHandler = new ObjectMovementHandler(playerList, ghostList);
	    
	    System.out.println("Not Calling Animation Updater...");
	      //AnimationUpdater animationUpdater = new AnimationUpdater(playerList);
		
		System.out.println("Game Starting...\n\n");
		
		String dir;
		Scanner input = new Scanner(System.in);
		while(true) {
			if(pacmanPlayer1.isAlive()) {
				System.out.println("Please enter a direction (up, down, right, left):");
				do {
					dir = input.nextLine();
					if(!(dir.equals("up") || dir.equals("down") || dir.equals("left") || dir.equals("right"))) {
						System.out.println("Invalid direction, please enter (up, down, right, left):");
					}
				}
				while(!(dir.equals("up") || dir.equals("down") || dir.equals("left") || dir.equals("right")));
				switch(dir) {
				case("up"):
					pacmanPlayer1.pDir = "up";
					break;
				case("down"):
					pacmanPlayer1.pDir = "down";
					break;
				case("right"):
					pacmanPlayer1.pDir = "right";
					break;
				case("left"):
					pacmanPlayer1.pDir = "left";
					break;
				}
			}
			for(int i = 0; i<3; i++) {
				try {
					Thread.sleep(500);
				}
				catch(Exception ex) {}
				if(pacmanPlayer1.isAlive()) {
					System.out.println("Player Heading "+pacmanPlayer1.getDir()+" with Pos:("+pacmanPlayer1.getX()+","+pacmanPlayer1.getY()+"), Ghost Pos:("+ghostAI1.getX()+","+ghostAI1.getY()+")");
				}
				else {
					System.out.println("Player (dead), Ghost Pos:("+ghostAI1.getX()+","+ghostAI1.getY()+")");
				}
			}
		}
	}

    
    public AI addGhost(JLabel iLabel, JPanel iPanel, String imageFilePath, String iName) {
    	iLabel = new JLabel("");
    	iLabel.setBounds(10, 10, 36, 36);
		iPanel.add(iLabel);
		
		return new AI(iLabel, imageFilePath, iName);
    }
}
