import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class AnimationUpdater {
	private Thread Updater = new Thread(new updater(), "Animation Updater");
	private Player player1;
	private Player player2;
	private String[] playerAnimEating = {"Eating1", "Eating2", "Eating3", "Eating4", "Eating5", 
								 "Eating6", "Eating7", "Eating8", "Eating7", "Eating6", 
								 "Eating5", "Eating4", "Eating3", "Eating2", "Eating1"};
	private String[] playerAnimDeath = {"Death1", "Death2", "Death3", "Death4", "Death5", 
								"Death6", "Death7", "Death8"};
	
	AnimationUpdater(Player[] iPlayerList){
		player1 = iPlayerList[0];
		System.out.println("Starting Animation Updater Runnable...");
		Updater.start();
	}
	
	public class updater implements Runnable{
		@Override
		public void run() {
			while(true) {
				
				try {
					Thread.sleep(100);
				}
				catch(Exception ex) {System.out.println(ex);}
				
				if(!player1.isAlive() && player1.playerLabel.isVisible() == true) {
					System.out.println("Hitbox Overlap Detected...");
					System.out.println("Starting Player Death Animation...");
					DeathAnimation(player1);
					System.out.println("Killing Player...");
					System.out.println("Ending Game Due to Dead Player...");
					System.exit(0);
				}
				
				for(String anim: playerAnimEating) {
					if(player1.isAlive()) {
						player1.playerLabel.setIcon(getImage("Pacman"+anim+".png", player1.getDir()));
					}
					try {
						Thread.sleep(20);
					}
					catch(Exception ex) {System.out.println(ex);}
				}
			}
		}
	}
	
	public void DeathAnimation(Player player) {
		for(String anim: playerAnimDeath) {
			try {
				Thread.sleep(50);
			}
			catch(Exception ex) {System.out.println(ex);}
			player.playerLabel.setIcon(getImage("Pacman"+anim+".png", player.getDir()));
		}
		player.playerLabel.setVisible(false);
	}
	public ImageIcon getImage(String s, String dir){
		double num = 0;
		BufferedImage bImage = null;
		try {
			bImage = ImageIO.read(new File(s));
		}
		catch(Exception ex) {}
		switch(dir) {
		case("up"):
			num = 1.5;
			break;
		case("down"):
			num = 0.5;
			break;
		case("right"):
			num = 0;
			break;
		case("left"):
			num = 1;
			break;
		}
		bImage = rotateClockwise90(bImage, num);
		return new ImageIcon(bImage);
	}
	
	public static BufferedImage rotateClockwise90(BufferedImage src, double num) {
	    int width = 36;
	    int height = 36;
	    
	    BufferedImage dest = new BufferedImage(height, width, src.getType());

	    Graphics2D graphics2D = dest.createGraphics();
	    graphics2D.rotate(Math.PI*num, height / 2, width / 2);
	    graphics2D.drawRenderedImage(src, null);
	    graphics2D.dispose();

	    return dest;
	}
}
