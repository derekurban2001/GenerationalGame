import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class AI{

	private char[] moveList = {'w', 'a', 's', 'd'};
	private String pDir = "up", sDir = "up", name;
	private boolean[] horizontalList, verticalList;
	private int x = 252, y = 260, oldX = -1, oldY = -1, xSpeed = 0, ySpeed = 0;
	private JLabel ghostLabel;
	
	AI(JLabel iJLabel, String imageFilePath, String iName){
		name = iName;
		ghostLabel = iJLabel;
		ghostLabel.setIcon(new ImageIcon(imageFilePath));
	}
	
	private void pickMovement(String iDir) {
		String tempDir = "";
		do {
			int random = (int)(Math.random()*4)+1;
			switch(random) {
			case(1):
				tempDir = "up";
				break;
			case(2):
				tempDir = "left";
				break;
			case(3):
				tempDir = "down";
				break;
			case(4):
				tempDir = "right";
				break;
			}
		}
		while(tempDir.equals(iDir));
		sDir = tempDir;
	}
	
	public void move() {
		updateVerticalList();
    	updateHorizontalList();
 		int i = -1;
 		
 		if(sDir == "up" || sDir == "down") {
 			do {
        		i += 1;
        		if(sDir == "up") {
        			ySpeed = -1;
        			updateVerticalList();
        			if(verticalList[i]) {
        				pDir = "up";
        				pickMovement("down");
        				y += ySpeed;
        			}
        		}
        		else if(sDir == "down" && x != 252) {
        			ySpeed = 1;
        			updateVerticalList();
        			if(verticalList[i]) {
        				pDir = "down";
        				pickMovement("up");
        				y += ySpeed;
        			}
        		}                		
        	}
        	while(verticalList[i] == false && i < verticalList.length-1);
 		}
 		else if(sDir == "left" || sDir == "right") {
 			do {
        		i += 1;
        		if(sDir == "left") {
        			xSpeed = -1;
        			updateHorizontalList();
        			if(horizontalList[i]) {
        				pDir = "left";
        				pickMovement("right");
        				x += xSpeed;
        			}
        		}
        		else if(sDir == "right") {
        			xSpeed = 1;
        			updateHorizontalList();
        			if(horizontalList[i]) {
        				pDir = "right";
        				pickMovement("left");
        				x += xSpeed;
        			}
        		}
        	}
        	while(horizontalList[i] == false && i < horizontalList.length-1);
 		}
 		i = -1;
 		if(pDir == "up" || pDir == "down") {
 			do {
        		i += 1;
        		if(pDir == "up") {
        			ySpeed = -1;
        			updateVerticalList();
        			if(verticalList[i]) {
        				y += ySpeed;
        			}
        		}
        		else if(pDir == "down" && x != 252) {
        			ySpeed = 1;
        			updateVerticalList();
        			if(verticalList[i]) {
        				y += ySpeed;
        			}
        		}
        	}
        	while(verticalList[i] == false && i < verticalList.length-1);
 		}
 		else if(pDir == "left" || pDir == "right") {
 			do {
        		i += 1;
        		if(pDir == "left") {
        			xSpeed = -1;
        			updateHorizontalList();
        			if(horizontalList[i]) {
        				x += xSpeed;
        			}
        		}
        		else if(pDir == "right") {
        			xSpeed = 1;
        			updateHorizontalList();
        			if(horizontalList[i]) {
        				x += xSpeed;
        			}
        		}
        	}
        	while(horizontalList[i] == false && i < horizontalList.length-1);
 		}
 		if(oldX == x && (pDir == "left" || pDir == "right")) {
			if(sDir == "up") {
				sDir = "down";
			}
			else if(sDir == "down") {
				sDir = "up";
			}
		}
 		else if(oldY == y && (pDir == "down" || pDir == "up")) {
			if(sDir == "left") {
				sDir = "right";
			}
			else if(sDir == "right") {
				sDir = "left";
			}
		}
 		if(x == 0 && y == 261) {
 			x = 502;
    	}
    	else if(x==503 && y == 261) {
    		x = 1;
    	}
 		oldX = x;
 		oldY = y;
        ghostLabel.setLocation(x, y);
	}
	
	private void updateHorizontalList() {
    	horizontalList = new boolean[]{(x+xSpeed>=10 && x+xSpeed<=223 && y==10),
    								   (x+xSpeed>=281 && x+xSpeed<=493 && y==10),
    								   (x+xSpeed>=10 && x+xSpeed<=493 && y==87),
    								   (x+xSpeed>=10 && x+xSpeed<=106 && y==145),
    								   (x+xSpeed>=396 && x+xSpeed<=493 && y==145),
    								   (x+xSpeed>=165 && x+xSpeed<=223 && y==145),
    								   (x+xSpeed>=281 && x+xSpeed<=339 && y==145),
    								   (x+xSpeed>=165 && x+xSpeed<=339 && y==203),
    								   (x+xSpeed>=0 && x+xSpeed<=165 && y==261),
    								   (x+xSpeed>=339 && x+xSpeed<=503 && y==261),
    								   (x+xSpeed>=165 && x+xSpeed<=339 && y==319),
    								   (x+xSpeed>=10 && x+xSpeed<=223 && y==377),
    								   (x+xSpeed>=281 && x+xSpeed<=493 && y==377),
    								   (x+xSpeed>=10 && x+xSpeed<=47 && y==435),
    								   (x+xSpeed>=453 && x+xSpeed<=493 && y==435),
    								   (x+xSpeed>=106 && x+xSpeed<=396 && y==435),
    								   (x+xSpeed>=10 && x+xSpeed<=106 && y==493),
    								   (x+xSpeed>=396 && x+xSpeed<=493 && y==493),
    								   (x+xSpeed>=165 && x+xSpeed<=223 && y==493),
    								   (x+xSpeed>=281 && x+xSpeed<=339 && y==493),
    								   (x+xSpeed>=10 && x+xSpeed<=493 && y==550)};
    }
	
	private void updateVerticalList() {
    	verticalList = new boolean[]{(y+ySpeed>=10 && y+ySpeed<=145 && x==10),
    								 (y+ySpeed>=377 && y+ySpeed<=435 && x==10),
    								 (y+ySpeed>=493 && y+ySpeed<=550 && x==10),
    								 (y+ySpeed>=435 && y+ySpeed<=493 && x==47),
    								 (y+ySpeed>=10 && y+ySpeed<=493 && x==106),
    								 (y+ySpeed>=87 && y+ySpeed<=145 && x==165),
    								 (y+ySpeed>=203 && y+ySpeed<=377 && x==165),
    								 (y+ySpeed>=435 && y+ySpeed<=493 && x==165),
    								 (y+ySpeed>=10 && y+ySpeed<=87 && x==223),
    								 (y+ySpeed>=145 && y+ySpeed<=203 && x==223),
    								 (y+ySpeed>=377 && y+ySpeed<=435 && x==223),
    								 (y+ySpeed>=493 && y+ySpeed<=550 && x==223),
    								 (y+ySpeed>=203 && y+ySpeed<=260 && x==252),
    								 (y+ySpeed>=10 && y+ySpeed<=87 && x==281),
    								 (y+ySpeed>=145 && y+ySpeed<=203 && x==281),
    								 (y+ySpeed>=377 && y+ySpeed<=435 && x==281),
    								 (y+ySpeed>=493 && y+ySpeed<=550 && x==281),
    								 (y+ySpeed>=87 && y+ySpeed<=145 && x==339),
    								 (y+ySpeed>=203 && y+ySpeed<=377 && x==339),
    								 (y+ySpeed>=435 && y+ySpeed<=493 && x==339),
    								 (y+ySpeed>=10 && y+ySpeed<=493 && x==396),
    								 (y+ySpeed>=435 && y+ySpeed<=493 && x==453),
    								 (y+ySpeed>=10 && y+ySpeed<=145 && x==493),
    								 (y+ySpeed>=377 && y+ySpeed<=435 && x==493),
    								 (y+ySpeed>=493 && y+ySpeed<=550 && x==493)};
    }
	
	public String toString() {
		return name;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
}
