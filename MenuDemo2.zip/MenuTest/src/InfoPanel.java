import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class InfoPanel{
	private ImageIcon NextBIcon, NextBHIcon, BackBIcon, BackBHIcon, BackgroundIcon, XBIcon, XBHIcon;
	public JPanel panel;
	private JPanel openingPanel;
	private JPanel characterPanel;
	
	public InfoPanel() {
		try {
			NextBIcon = new ImageIcon(ImageIO.read(new File("images/NextButton.png")));
			NextBHIcon = new ImageIcon(ImageIO.read(new File("images/NextButtonHighlighted.png")));
			BackBIcon = new ImageIcon(ImageIO.read(new File("images/BackButton.png")));
			BackBHIcon = new ImageIcon(ImageIO.read(new File("images/BackButtonHighlighted.png")));
			XBIcon = new ImageIcon(ImageIO.read(new File("images/XButton.png")));
			XBHIcon = new ImageIcon(ImageIO.read(new File("images/XButtonHighlighted.png")));
			BackgroundIcon = new ImageIcon(ImageIO.read(new File("images/DefaultPanelBackground.png")));
		}
		catch(Exception ex) {}
		
		panel = new JPanel();
		panel.setBackground(Color.GRAY);
		panel.setBorder(null);
		panel.setBounds(40, 26, 670, 670);
		panel.setLocation(335-(panel.getWidth()/2), 335-(panel.getHeight()/2));
		panel.setLayout(null);
		
		JButton jNextButton = new JButton("");
		jNextButton.setIcon(NextBIcon);
		jNextButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				jNextButton.setIcon(NextBHIcon);
			}
			public void mouseExited(MouseEvent arg0) {
				jNextButton.setIcon(NextBIcon);
			}
		});
		jNextButton.setBorder(null);
		jNextButton.setBorderPainted(false);
		jNextButton.setContentAreaFilled(false);
		jNextButton.setFocusable(false);		
		jNextButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jNextButtonActionPerformed();
			}
		});
		jNextButton.setBounds(514, 39, 89, 51);
		panel.add(jNextButton);
		
		JButton jBackButton = new JButton("");
		jBackButton.setIcon(BackBIcon);
		jBackButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				jBackButton.setIcon(BackBHIcon);
			}
			public void mouseExited(MouseEvent arg0) {
				jBackButton.setIcon(BackBIcon);
			}
		});
		jBackButton.setBorder(null);
		jBackButton.setBorderPainted(false);
		jBackButton.setContentAreaFilled(false);
		jBackButton.setFocusable(false);		
		jBackButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				jBackButtonActionPerformed();
			}
		});
		jBackButton.setBounds(45, 39, 89, 51);
		panel.add(jBackButton);
		
		JButton jExitButton = new JButton("");
		jExitButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				jExitButton.setIcon(XBHIcon);
			}
			public void mouseExited(MouseEvent e) {
				jExitButton.setIcon(XBIcon);
			}
		});
		jExitButton.setIcon(XBIcon);
		jExitButton.setFocusable(false);
		jExitButton.setContentAreaFilled(false);
		jExitButton.setBorder(null);
		jExitButton.setBackground(new Color(0,0,0,0));
		jExitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		jExitButton.setBounds(631, 0, 41, 41);
		panel.add(jExitButton);
		
		JLabel lblNewLabel = new JLabel("INFO PANEL");
		lblNewLabel.setBounds(190, 222, 278, 88);
		panel.add(lblNewLabel);
		
		JLabel jBackground = new JLabel("");
		jBackground.setIcon(BackgroundIcon);
		jBackground.setBounds(0, 0, 670, 670);
		panel.add(jBackground);
		
		panel.setVisible(false);
		panel.setOpaque(false);
	}
	
	private void jNextButtonActionPerformed() {
		characterPanel.setVisible(true);
		panel.setVisible(false);
	}
	
	private void jBackButtonActionPerformed() {
		openingPanel.setVisible(true);
		panel.setVisible(false);
	}
	
	public void setPanels(JPanel OpeningPanel, JPanel CharacterPanel) {
		openingPanel = OpeningPanel;
		characterPanel = CharacterPanel;
	}
}
