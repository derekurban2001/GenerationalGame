import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

public class OpeningPanel{
	
	private ImageIcon PlayBIcon, PlayBHIcon, ExitBIcon, ExitBHIcon, BackgroundIcon;
	public JPanel panel;
	private JPanel infoPanel;
	private JButton jPlayButton;

	public OpeningPanel() {
		try {
			PlayBIcon = new ImageIcon(ImageIO.read(new File("images/PlayButton.png")));
			PlayBHIcon = new ImageIcon(ImageIO.read(new File("images/PlayButtonHighlighted.png")));
			ExitBIcon = new ImageIcon(ImageIO.read(new File("images/ExitButton.png")));
			ExitBHIcon = new ImageIcon(ImageIO.read(new File("images/ExitButtonHighlighted.png")));
			BackgroundIcon = new ImageIcon(ImageIO.read(new File("images/OpeningFrameBackground.png")));
		}
		catch(Exception ex) {}
		panel = new JPanel();
		panel.setOpaque(false);
		panel.setBackground(Color.GRAY);
		panel.setBorder(null);
		panel.setBounds(40, 26, 400, 200);
		panel.setLocation(335-(panel.getWidth()/2), 335-(panel.getHeight()/2));
		panel.setLayout(null);
		
		jPlayButton = new JButton("");
		jPlayButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent arg0) {
				jPlayButton.setIcon(PlayBHIcon);
			}
			public void mouseExited(MouseEvent arg0) {
				jPlayButton.setIcon(PlayBIcon);
			}
		});
		jPlayButton.setIcon(PlayBIcon);
		jPlayButton.setBorder(null);
		jPlayButton.setBorderPainted(false);
		jPlayButton.setContentAreaFilled(false);
		jPlayButton.setFocusable(false);
		jPlayButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jPlayButtonActionPerformed();
			}
		});
		jPlayButton.setBounds(258, 111, 87, 51);
		panel.add(jPlayButton);
		
		JButton jExitButton = new JButton("");
		jExitButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				jExitButton.setIcon(ExitBHIcon);
			}
			public void mouseExited(MouseEvent e) {
				jExitButton.setIcon(ExitBIcon);
			}
		});
		jExitButton.setIcon(ExitBIcon);
		jExitButton.setFocusable(false);
		jExitButton.setContentAreaFilled(false);
		jExitButton.setBorder(null);
		jExitButton.setBackground(new Color(0,0,0,0));
		jExitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		jExitButton.setBounds(47, 111, 87, 51);
		panel.add(jExitButton);
		
		JLabel background = new JLabel("");
		background.setIcon(BackgroundIcon);
		background.setBounds(0, 0, 400, 200);
		panel.add(background);
	}

	
	private void jPlayButtonActionPerformed() {
		infoPanel.setVisible(true);
		panel.setVisible(false);
	}
	
	public void setPanels(JPanel InfoPanel) {
		infoPanel = InfoPanel;
	}
}
