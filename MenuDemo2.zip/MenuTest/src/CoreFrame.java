import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class CoreFrame extends JFrame {

	JPanel contentPane;
	OpeningPanel openingPanel = new OpeningPanel();
	InfoPanel infoPanel = new InfoPanel();
	CharacterPanel characterPanel = new CharacterPanel();
	GamePanel gamePanel = new GamePanel();
		
	public CoreFrame() {
		setUndecorated(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 670, 670);
		contentPane = new JPanel();
		contentPane.setBorder(null);
		setContentPane(contentPane);
		setBackground(new Color(0,0,0,0));
		setLocationRelativeTo(null);
		contentPane.setLayout(null);
		
		initPanels();
	}
	
	private void initPanels() {
		contentPane.add(openingPanel.panel);
		contentPane.add(infoPanel.panel);
		contentPane.add(characterPanel.panel);
		contentPane.add(gamePanel.panel);
		openingPanel.setPanels(infoPanel.panel);
		infoPanel.setPanels(openingPanel.panel, characterPanel.panel);
		characterPanel.setPanels(infoPanel.panel, gamePanel.panel);
		gamePanel.setPanels(characterPanel.panel);
	}
}
