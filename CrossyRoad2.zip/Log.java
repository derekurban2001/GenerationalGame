

class Log extends Obstacles {

  Log(float x, float y, float w, float h, float s) {
    super(x, y, w, h, s);
  }
}