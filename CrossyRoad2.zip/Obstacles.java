
/*public class Obstacles extends Rectangle {
	 float speed;

	  Obstacles(float x, float y, float w, float h, float s) {
	    super(x, y, w, h);
	    speed = s;
	  }

	  void update() {

	  }
}
*/