import java.util.Scanner;

public class Movement /*extends KeyAdapter */ {
	
	//instance variables
	private Player player;
	//private Obstacles obstacle;
	private boolean moving;
	
	//constructor
	public Movement () {
		//player = new Player();
		//obstacle = new Obstacles();
		moving = false;
	} 
	
	
	public void movePlayerForward() {
		Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.println("Press Enter: ");
		String n = reader.next(); // Scans the next token of the input as an int.
		
		if(n.equals("s")) {
			player.updateYlocation(1.0);
			System.out.println(player.getYLocation());
		}
		else if(n.equals("n")) {
			System.exit(0);
		}
		
		
	}
	
}