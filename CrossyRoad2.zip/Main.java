import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
public class Main {

	
	public static void main(String[] args) {
		Movement movement = new Movement();
		while(true) {
			movement.movePlayerForward();
			try {
				Thread.sleep(50);
			}
			catch(Exception ex) {};
		}
	}

}
