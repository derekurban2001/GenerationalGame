
public class Player extends Rectangle{
	//make the player a rectangle
	
	Player(float x, float y, float size){
		// we want the player to be a square 
		super(x, y, size, size);
		
	}
	
	//create a function that shows the player
	public void show() {
		
		//fill(255);
		//rectMode(CORNER);
		//Rectangle(left, top, right, bottom);
		
		
		
	}
	
	//clear a function that updates the player
	public void update() {
		
	}
	
	

}
