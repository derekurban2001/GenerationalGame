
public class Log {

}
