
public class Rectangle {
	protected float left;
	protected float right;
	protected float top;
	protected float bottom;
	
	//create an x and y a width and a height
	Rectangle(float x, float y, float w, float h){
		//left is x
		left = x;
		//right is x + width 
		right = w+x;
		//top is y
		top = y;
		//bottom is height + y 
		bottom = h+y;
	}
	
	//see if a rectangle is intersecting another rectangle 
	boolean intersects(Rectangle other) {
		//if left side of this rectangle is bigger than the right side of other rectangles then they do not intersect
		//or
		//if right side of this rectangle is smaller than the left side of other rectangles then they do not intersect 
		//or
		//if top side of this rectangle is bigger than the bottom of other rectangles then they do not intersect
		//or
		//if bottom of this rectangle is smaller than the top of other rectangles then they do not intersect
		//if any of these don't happen then they intersect
		return !(this.left >other.right|| this.right<other.left||this.top>other.bottom||this.bottom<other.top);
	}
	
	

}
