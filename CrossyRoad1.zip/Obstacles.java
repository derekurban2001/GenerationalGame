
public class Obstacles extends Rectangle {
	 float speed;

	  Obstacles(float x, float y, float w, float h, float s) {
	    super(x, y, w, h);
	    speed = s;
	  }

	  void update() {

	  }
	  void show() {
	    //fill(200);
	   // rect(x, y, w, h);
	  }

}
