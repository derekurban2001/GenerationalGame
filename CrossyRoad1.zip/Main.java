
public class Main {
	Player player;
	
	public void setup() {
		//create size for player
		//width and height
		size(100, 100);
		//player equals new player
		player = new Player(100,100,100);
	}
	
	private void size(int i, int j) {
		// TODO Auto-generated method stub
		
	}

	public void draw() {
		background(0);
		player.show();
	}

}
