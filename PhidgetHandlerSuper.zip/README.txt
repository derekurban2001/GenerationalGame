The PhidgetHandlerSuper.java is a superclass that all input
classes should extend for this project.

It will handle very basic key input actions and will perform
code when any of the four keys are pressed. Current default
keybinds are:
	Player 1: Q
	Player 2: R
	Player 3: U
	Player 4: P

This version is currently modified to help make implementation
for your individual projects easier.

INSTALLATION:
1. Copy and paste the PhidgetHandlerSuper.java class into the
   src of your project, or wherever all your .java classes are 
   located

2. Find where your main JFrame or JPanel component (usually
   named contentPane) is located, and declare it as static.

3. Go back into the PhidgetHandlerSuper.java class and replace
   "contentPane" (it should be underlined in red) with
   <ClassWithMainFrame>.<MainFrameVariable>, for example
   GUI.contentPane

4. Then simply have your imput class extend the super class
   implement the required abstract classes:
	playerOneAction();
	playerTwoAction();
	playerThreeAction();
	playerFourAction();

5. You're good to go!

