//package superclasses; Meant for final copy
//import static pixelpartymenu.CoreFrame.contentPane; Meant for final copy

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.KeyStroke;

public abstract class PhidgetHandlerSuper{
	
	private static final String PLAYER_ONE = "playerOne";
	private static final String PLAYER_TWO = "playerTwo";
	private static final String PLAYER_THREE = "playerThree";
	private static final String PLAYER_FOUR = "playerFour";
	private static InputMap iMap;
	private static ActionMap aMap;
	
	protected PhidgetHandlerSuper(){
		addKeyBind("Q", "playerOne", playerOnePerformAction);
		addKeyBind("R", "playerTwo", playerTwoPerformAction);
		addKeyBind("U", "playerThree", playerThreePerformAction);
		addKeyBind("P", "playerFour", playerFourPerformAction);
	}
	
	public abstract void playerOneAction();
	public abstract void playerTwoAction();
	public abstract void playerThreeAction();
	public abstract void playerFourAction();
	
	private void addKeyBind(String key, String playerConstant, Action act) {
		//replace contentPane with a static JFrame or JPanel from the main class of your program.
		//For example, if you have a contentPane in your GUI.java class, initialize the contentPane as
		//static, then use <GUI.contentPane> to replace.
	    iMap = contentPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
	    aMap = contentPane.getActionMap();
	    iMap.put(KeyStroke.getKeyStroke(key), playerConstant);
	    aMap.put(playerConstant, act);
	}
	
	Action playerOnePerformAction = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {
			playerOneAction();
		}
	};
	
	Action playerTwoPerformAction = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {
			playerTwoAction();
		}
	};
	
	Action playerThreePerformAction = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {
			playerThreeAction();
		}
	};
	
	Action playerFourPerformAction = new AbstractAction() {
		@Override
		public void actionPerformed(ActionEvent e) {
			playerFourAction();
		}
	};
}
